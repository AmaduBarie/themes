import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tooltip-basic',
  templateUrl: './tooltip-basic.component.html',
  styleUrls: ['./tooltip-basic.component.css']
})
export class TooltipBasicComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
