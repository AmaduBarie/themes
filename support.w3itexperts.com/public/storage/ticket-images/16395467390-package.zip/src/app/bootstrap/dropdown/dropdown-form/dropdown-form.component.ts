import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dropdown-form',
  templateUrl: './dropdown-form.component.html',
  styleUrls: ['./dropdown-form.component.css']
})
export class DropdownFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
