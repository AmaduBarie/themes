import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dropdown-manual',
  templateUrl: './dropdown-manual.component.html',
  styleUrls: ['./dropdown-manual.component.css']
})
export class DropdownManualComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
