import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dropdown-split',
  templateUrl: './dropdown-split.component.html',
  styleUrls: ['./dropdown-split.component.css']
})
export class DropdownSplitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
