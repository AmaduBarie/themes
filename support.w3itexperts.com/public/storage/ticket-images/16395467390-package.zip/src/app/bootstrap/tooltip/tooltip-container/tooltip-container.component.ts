import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tooltip-container',
  templateUrl: './tooltip-container.component.html',
  styleUrls: ['./tooltip-container.component.css']
})
export class TooltipContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
