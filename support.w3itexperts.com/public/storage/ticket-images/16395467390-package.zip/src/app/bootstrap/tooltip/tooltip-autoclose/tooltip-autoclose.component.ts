import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tooltip-autoclose',
  templateUrl: './tooltip-autoclose.component.html',
  styleUrls: ['./tooltip-autoclose.component.css']
})
export class TooltipAutocloseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
