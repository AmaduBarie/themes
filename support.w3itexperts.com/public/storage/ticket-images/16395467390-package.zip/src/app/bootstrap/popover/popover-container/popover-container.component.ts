import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popover-container',
  templateUrl: './popover-container.component.html',
  styleUrls: ['./popover-container.component.css']
})
export class PopoverContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
