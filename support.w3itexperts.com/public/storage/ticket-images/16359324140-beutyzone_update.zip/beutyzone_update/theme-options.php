<?php
/**
 ReduxFramework Theme Option File
 For full documentation, please visit: https://github.com/ReduxFramework/ReduxFramework/wiki
 *
 */
 
if (!class_exists("ReduxFramework"))
{
    return;
}

if (!class_exists("Beautyzone_Redux_Framework_config"))
{
    class Beautyzone_Redux_Framework_config
    {

        public $args = array();
        public $sections = array();
        public $theme;
        public $ReduxFramework;
        public $page_template_options;
        public $coming_template_options;
        public $maintenance_template_options;
        public $error_template_options;
        public $header_style_options;
        public $footer_style_options;
        public $post_layouts_options;
        public $sidebar_layout_options;
        public $page_banner_options;
        public $post_banner_options;
        public $theme_layout_options;
        public $theme_color_background_options;
        public $theme_image_background_options;
        public $theme_pattern_background_options;
        public $theme_color_options;
        public $page_loader_options;
        public $sort_by_options;
        public $link_target_options;
        public $social_link_options;
        public $banner_type;

        function __construct()
        {

            /** Option Variable assigning values **/
            $this->page_template_options = beautyzone_get_page_template_options();
            $this->coming_template_options = beautyzone_get_coming_template_options();
            $this->maintenance_template_options = beautyzone_get_maintenance_template_options();
            $this->error_template_options = beautyzone_get_error_template_options();
            $this->header_style_options = beautyzone_get_header_style_options();
            $this->footer_style_options = beautyzone_get_footer_style_options();
            $this->post_layouts_options = beautyzone_get_post_layouts_options();
            $this->sidebar_layout_options = beautyzone_get_sidebar_layout_options();
            $this->page_banner_options = beautyzone_get_page_banner_options();
            $this->post_banner_options = beautyzone_get_post_banner_options();
            $this->theme_layout_options = beautyzone_get_theme_layout_options();
            $this->theme_color_background_options = beautyzone_get_theme_color_background_options();
            $this->theme_image_background_options = beautyzone_get_theme_image_background_options();
            $this->theme_pattern_background_options = beautyzone_get_theme_pattern_background_options();
            $this->theme_color_options = beautyzone_get_theme_color_options();
            $this->page_loader_options = beautyzone_get_page_loader_options();
            $this->sort_by_options = beautyzone_get_sort_by_options();
            $this->link_target_options = beautyzone_get_link_target_options();
            $this->social_link_options = beautyzone_get_social_link_options();
            $this->social_share_options = beautyzone_get_social_share_options();
            $this->banner_type = beautyzone_banner_type();
            /** End Option Variable assigning values **/

            // Just for demo purposes. Not needed per say.
            $this->theme = wp_get_theme();

            // Set the default arguments
            $this->setArguments();

            // array of widgets
            $this->beautyzone_get_wp_widgets();

            // Create the sections and fields
            $this->setSections();

            // default theme options
            // $this->beautyzone_get_default_option();
            if (!isset($this->args['opt_name']))
            { // No errors please
                return;
            }
            $this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
        }

        /**
         * All the possible arguments for Redux.
         * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
         *
         */

        function setArguments()
        {

            $theme = wp_get_theme(); // For use with some settings. Not necessary.
            $opt_name = beautyzone_get_opt_name();

            $this->args = array(

                // TYPICAL -> Change these values as you need/desire
                'opt_name' => $opt_name,
                // This is where your data is stored in the database and also becomes your global variable name.
                'display_name' => $theme->get('Name') ,
                // Name that appears at the top of your panel
                'display_version' => $theme->get('Version') ,
                // Version that appears at the top of your panel
                'menu_type' => class_exists('DZCore') ? 'menu' : '',
                //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                'allow_sub_menu' => false,
                // Show the sections below the admin menu item or not
                'menu_title' => esc_html__('Theme Options', 'beautyzone') ,
                'page_title' => esc_html__('Theme Options', 'beautyzone') ,
                // You will need to generate a Google API key to use this feature.
                // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
                'google_api_key' => '',
                // Set it you want google fonts to update weekly. A google_api_key value is required.
                'google_update_weekly' => false,
                // Must be defined to add google fonts to the typography module
                'async_typography' => false,
                // Use a asynchronous font on the front end or font string
                //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
                'admin_bar' => false,
                // Show the panel pages on the admin bar
                'admin_bar_icon' => 'dashicons-admin-generic',
                // Choose an icon for the admin bar menu
                'admin_bar_priority' => 50,
                // Choose an priority for the admin bar menu
                'global_variable' => '',
                // Set a different name for your global variable other than the opt_name
                'dev_mode' => true,
                // Show the time the page took to load, etc
                'update_notice' => true,
                // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
                'customizer' => true,
                // Enable basic customizer support
                //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
                //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field
                'show_options_object' => false,
                // OPTIONAL -> Give you extra features
                'page_priority' => null,
                // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                'page_parent' => class_exists('DZCore') ? $theme->get('TextDomain') : '',
                // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                'page_permissions' => 'manage_options',
                // Permissions needed to access the options panel.
                'menu_icon' => '',
                // Specify a custom URL to an icon
                'last_tab' => '',
                // Force your panel to always open to a specific tab (by id)
                'page_icon' => 'icon-themes',
                // Icon displayed in the admin panel next to your menu_title
                'page_slug' => 'theme-options',
                // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
                'save_defaults' => true,
                // On load save the defaults to DB before user clicks save or not
                'default_show' => false,
                // If true, shows the default value next to each field that is not the default value.
                'default_mark' => '',
                // What to print by the field's title if the value shown is default. Suggested: *
                'show_import_export' => true,
                // Shows the Import/Export panel when not used as a field.
                // CAREFUL -> These options are for advanced use only
                'transient_time' => 60 * MINUTE_IN_SECONDS,
                'output' => true,
                // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                'output_tag' => false,
                // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.
                // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                'database' => '',
                // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                'use_cdn' => true,
                // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.
                // HINTS
                'hints' => array(
                    'icon' => 'el el-question-sign',
                    'icon_position' => 'right',
                    'icon_color' => '#1085e4',
                    'icon_size' => '10',
                    'tip_style' => array(
                        'color' => '#1085e4',
                        'shadow' => true,
                        'rounded' => false,
                        'style' => '',
                    ) ,
                    'tip_position' => array(
                        'my' => 'top left',
                        'at' => 'bottom right',
                    ) ,
                    'tip_effect' => array(
                        'show' => array(
                            'effect' => 'slide',
                            'duration' => '500',
                            'event' => 'mouseover',
                        ) ,
                        'hide' => array(
                            'effect' => 'slide',
                            'duration' => '500',
                            'event' => 'click mouseleave',
                        ) ,
                    ) ,
                ) ,
                'templates_path' => class_exists('DZCore') ? dzcore()
                    ->path('APP_DIR') . '/templates/redux/' : '',
            );
        }

        /**
         * Custom query for widget list array
         *
         * @param  array $all_widgets
         */
        function beautyzone_get_wp_widgets()
        {

            global $wpdb;
            $table = $wpdb->prefix . 'options';
            $attrPrefix = 'widget_';

            $result = $wpdb->get_results("SELECT `option_id`, `option_name` FROM $table WHERE `option_name` LIKE '%$attrPrefix%' AND `option_name` != 'sidebars_widgets' ORDER BY `option_id` ASC");

            $all_widgets = array();

            foreach ($result as $widget)
            {
                $all_widgets[$widget->option_name] = ucwords(str_replace("_", " ", $widget->option_name));
            }

            return $all_widgets;
        }

        /**
         * All the possible sections for Redux.
         *
         */
        function setSections()
        {

            /*--------------------------------------------------------------
            # 1. General Settings
            --------------------------------------------------------------*/
            $this->sections[] = array(
                'title' => esc_html__('General Settings', 'beautyzone') ,
                'desc' => esc_html__('General Settings is a global setting that will affects all the pages of you website. From here you can make changes globaly. The setting will apply if there is no individual settings.', 'beautyzone') ,
                'icon' => 'el-icon-home',
                'fields' => array(
                    array(
                        'id' => 'website_status',
                        'type' => 'button_set',
                        'title' => esc_html__('Website Status', 'beautyzone') ,
                        'subtitle' => esc_html__('Click on the option tabs to change the status of your website.', 'beautyzone') ,
                        'desc' => esc_html__('Select option tabs to change the status.', 'beautyzone') ,
                        'options' => array(
                            'live_mode' => esc_html__('Live', 'beautyzone') ,
                            'comingsoon_mode' => esc_html__('Coming Soon', 'beautyzone') ,
                            'maintenance_mode' => esc_html__('Site Down For Maintenance', 'beautyzone')
                        ) ,
                        'default' => 'live_mode',
                        'hint' => array(
                            'title' => esc_html__('Status', 'beautyzone') ,
                            'content' => esc_html__('1. Live status indicate that your website is available and operational.', 'beautyzone') . '<br><br>' . esc_html__('2. Coming Soon status show your website visitors that you are working on your website for making it better.', 'beautyzone') . '<br><br>' . esc_html__('3. Maintenance mode show your website visitors that you are working on your website for making it better.', 'beautyzone')
                        )
                    ) ,
                    array(
                        'id' => 'coming_soon_template',
                        'type' => 'image_select',
                        'title' => esc_html__('Coming Soon Template', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose the template for Coming Soon page. (Default : 1).', 'beautyzone') ,
                        'desc' => esc_html__('Click on the icon to change the template.', 'beautyzone') ,
                        'options' => $this->coming_template_options,
                        'default' => 'coming_style_1',
                        'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'comingsoon_mode'
                        ) ,
                        'hint' => array(
                            'title' => esc_html__('Hint Title', 'beautyzone') ,
                            'content' => esc_html__('Choose the coming soon template design as you want to show.', 'beautyzone')
                        )
                    ) ,
                    array(
                        'id' => 'comingsoon_bg',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Coming Soon Page Background', 'beautyzone') ,
                        'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'comingsoon_mode'
                        ) ,
                        'default' => array(
                            'url' => get_template_directory_uri() . '/assets/images/banner/pic2.jpg'
                        ) ,
                    ) ,
                    array(
                        'id' => 'comingsoon_launch_date',
                        'type' => 'date',
                        'title' => esc_html__('Coming soon Date', 'beautyzone') ,
                        'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'comingsoon_mode'
                        ) ,
                    ) ,
                    array(
                        'id' => 'maintenance_template',
                        'type' => 'image_select',
                        'title' => esc_html__('Maintenance Template', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose the template for Maintenance page. (Default : 1).', 'beautyzone') ,
                        'desc' => esc_html__('Click on the icon to change the template.', 'beautyzone') ,
                        'options' => $this->maintenance_template_options,
                        'default' => 'maintenance_style_1',
                        'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'maintenance_mode'
                        ) ,
                        'hint' => array(
                            'title' => esc_html__('Hint Title', 'beautyzone') ,
                            'content' => esc_html__('Choose the maintenance template design as you want to show.', 'beautyzone')
                        )
                    ) ,

                    array(
                        'id' => 'maintenance_bg',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Maintenance Background Image', 'beautyzone') ,
                        'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'maintenance_mode'
                        ) ,
                        'default' => array(
                            'url' => get_template_directory_uri() . '/assets/images/banner/pic1.jpg'
                        ) ,
                    ) ,
                    array(
                        'id' => 'maintenance_icon',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Maintenance Icon', 'beautyzone') ,
                        'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'maintenance_mode'
                        ) ,
                        'default' => array(
                            'url' => get_template_directory_uri() . '/assets/images/vlc.png'
                        ) ,
                    ) ,
                    array(
                        'id' => 'maintenance_title',
                        'type' => 'textarea',
                        'title' => esc_html__('Maintenance Page Title', 'beautyzone') ,
                        'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'maintenance_mode'
                        ) ,
                        'default' => esc_html__('Site Is Down', 'beautyzone') . ' <br/>' . esc_html__('For Maintenance', 'beautyzone') ,
                    ) ,
                    array(
                        'id' => 'maintenance_desc',
                        'type' => 'textarea',
                        'title' => esc_html__('Maintenance Page Description', 'beautyzone') ,
                        'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'maintenance_mode'
                        ) ,
                        'default' => esc_html__('This is the Technical Problems Page.', 'beautyzone') . ' <br/>' . esc_html__('Or any other page.', 'beautyzone') ,
                    ) ,
                    array(
                        'id' => 'logo_type',
                        'type' => 'button_set',
                        'title' => esc_html__('Logo Type', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose the logo type', 'beautyzone') ,
                        'desc' => esc_html__('Click o the tab to change the logo type.', 'beautyzone') ,
                        'options' => array(
                            'image_logo' => esc_html__('Image Logo', 'beautyzone') ,
                            'text_logo' => esc_html__('Text Logo', 'beautyzone')
                        ) ,
						'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'live_mode'
                        ) ,
                        'default' => 'image_logo',
                        'hint' => array(
                            'title' => esc_html__('Choose Logo Type:', 'beautyzone') ,
                            'content' => esc_html__('1. Image Logo will be the .pmg / .jpg type. This setting affects all the site pages.', 'beautyzone') . '<br><br>' . esc_html__('2. Text Logo will the text type. This setting affects all the site pages.', 'beautyzone')
                        )
                    ) ,
                    array(
                        'id' => 'blog_page_title',
                        'type' => 'text',
                        'title' => esc_html__('Blog Page Title', 'beautyzone') ,
                        'desc' => esc_html__('Default blog page title.', 'beautyzone') ,
                        'default' => esc_html__('Blog', 'beautyzone'),
						'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'live_mode'
                        ) ,
                    ) ,
                    array(
                        'id' => 'page_loading_on',
                        'type' => 'switch',
                        'title' => esc_html__('Page Loading', 'beautyzone') ,
                        'subtitle' => esc_html__('Click on the tab to Enable / Disable the page loading setting.', 'beautyzone') ,
                        'desc' => esc_html__('Once you click on disable, This setting affects all the site pages.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false,
						'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'live_mode'
                        ) ,
                    ) ,
                    
                    array(
                        'id' => 'show_social_icon',
                        'type' => 'switch',
                        'title' => esc_html__('Social Icon', 'beautyzone') ,
                        'subtitle' => esc_html__('Click on the tab to Enable / Disable the social icon setting.', 'beautyzone') ,
                        'desc' => esc_html__('Once you click on disable, This setting affects all the site pages.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false,
						'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'live_mode'
                        ) ,
                    ) ,
                    array(
                        'id' => 'show_breadcrumb',
                        'type' => 'switch',
                        'title' => esc_html__('Breadcrumb Area', 'beautyzone') ,
                        'subtitle' => esc_html__('Click on the tab to Enable / Disable the website breadcrumb.', 'beautyzone') ,
                        'desc' => esc_html__('Once you click on disable, This setting affects all the site pages.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true,
						'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'live_mode'
                        ) ,
						'hint' => array(
                            'title' => esc_html__('Select Breadcrumb Area:', 'beautyzone') ,
                            'content' => esc_html__('This breadcrumb option only works when page level banner Theme Settings option selected. This option will not work when custom settings selected.', 'beautyzone'),
                        )
                    ) ,
                    array(
                        'id' => 'show_login_registration',
                        'type' => 'switch',
                        'title' => esc_html__('Login / Register', 'beautyzone') ,
                        'subtitle' => esc_html__('Click on the tab to Enable / Disable the login / register button / likns.', 'beautyzone') ,
                        'desc' => esc_html__('Once you click on disable, This setting affects all the site pages.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false,
						'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'live_mode'
                        ) ,
                        'hint' => array(
                            'title' => esc_html__('Login/Register Visible', 'beautyzone') ,
                            'content' => esc_html__('This is show in top bar.', 'beautyzone')
                        )
                    ) ,
                    array(
                        'id' => 'show_sidebar',
                        'type' => 'switch',
                        'title' => esc_html__('Sidebar', 'beautyzone') ,
                        'subtitle' => esc_html__('Click on the tab to Enable / Disable the sidebar.', 'beautyzone') ,
                        'desc' => esc_html__('Once you click on disable, This setting affects all the site pages.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true,
						'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'live_mode'
                        ) ,
                    ) ,
                    
                    array(
                        'id' => 'map_api_key',
                        'type' => 'text',
                        'title' => esc_html__('Map Api Key', 'beautyzone') ,
                        'desc' => esc_html__('Input an API key to enable map.', 'beautyzone') ,
                        'default' => '',
						'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'live_mode'
                        ) ,
                    ) ,
                    array(
                        'id' => 'mailchimp',
                        'type' => 'switch',
                        'title' => esc_html__('Mailchimp', 'beautyzone') ,
                        'subtitle' => esc_html__('Click on the tab to Enable / Disable mailchimp subscription.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true,
						'required' => array(
                            0 => 'website_status',
                            1 => 'equals',
                            2 => 'live_mode'
                        ) ,
                    ) ,
                    array(
                        'id' => 'mailchimp_api_key',
                        'type' => 'text',
                        'title' => esc_html__('MailChimp Api Key', 'beautyzone') ,
                        'desc' => esc_html__('Input an API key to enable MailChimp.', 'beautyzone') ,
                        'default' => '',
                        'required' => array(
                            array(
                                0 => 'mailchimp',
                                1 => 'equals',
                                2 => 1
                            ) ,
							array(
								0 => 'website_status',
								1 => 'equals',
								2 => 'live_mode'
							) ,
                        )
                    ) ,
                    array(
                        'id' => 'mailchimp_list_id',
                        'type' => 'text',
                        'title' => esc_html__('MailChimp List ID', 'beautyzone') ,
                        'desc' => esc_html__('Input an List ID to enable MailChimp.', 'beautyzone') ,
                        'required' => array(
                            array(
                                0 => 'mailchimp',
                                1 => 'equals',
                                2 => 1
                            ) ,
							array(
								0 => 'website_status',
								1 => 'equals',
								2 => 'live_mode'
							) ,

                        )
                    )
                )
            );

            /*--------------------------------------------------------------
            # 2. Logo Settings
            --------------------------------------------------------------*/
            $this->sections[] = array(
                'title' => esc_html__('Logo Settings', 'beautyzone') ,
                'icon' => 'el el-cog-alt',
                'fields' => array(
                    array(
                        'id' => 'favicon',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Favicon', 'beautyzone') ,
                        'subtitle' => esc_html__('Select favicon image.', 'beautyzone') ,
                        'desc' => esc_html__('Upload favicon image.', 'beautyzone') ,
                        'default' => array(
                            'url' => get_template_directory_uri() . '/assets/images/favicon.ico'
                        ) ,
                        'hint' => array(
                            'title' => esc_html__('Favicon', 'beautyzone') ,
                            'content' => esc_html__('From here you can upload an image. This setting affects all the site pages.', 'beautyzone')
                        )
                    ) ,
                    array(
                        'id' => 'logo_text',
                        'type' => 'text',
                        'title' => esc_html__('Logo Text', 'beautyzone') ,
                        'subtitle' => esc_html__('Name your text logo.', 'beautyzone') ,
                        'default' => get_bloginfo('name') ,
                    ) ,
                    array(
                        'id' => 'tag_line',
                        'type' => 'text',
                        'title' => esc_html__('Tag Line', 'beautyzone') ,
                        'subtitle' => esc_html__('Name a tagline for the text logo.', 'beautyzone') ,
                        'default' => get_bloginfo('description') ,
                    ) ,
                    array(
                        'id' => 'logo_title',
                        'type' => 'text',
                        'title' => esc_html__('Logo Title', 'beautyzone') ,
                        'subtitle' => esc_html__('Title attribute for the logo. This attribute specifies extra information about the logo. Most browsers will show a tooltip with this text on logo hover.', 'beautyzone') ,
                        'default' => get_bloginfo('name') ,

                    ) ,
                    array(
                        'id' => 'logo_alt',
                        'type' => 'text',
                        'title' => esc_html__('Logo Alt', 'beautyzone') ,
                        'subtitle' => esc_html__('Alt attribute for the logo. This is the alternative text if the logo cannot be displayed. It`s useful for SEO and generally is the name of the site.', 'beautyzone') ,
                        'default' => get_bloginfo('name') ,
                    ) ,
                    array(
                        'id' => 'logo-section-start',
                        'type' => 'section',
                        'title' => esc_html__('Site Logo Setting', 'beautyzone') ,
                        'indent' => true
                    ) ,
                    array(
                        'id' => 'site_logo',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Logo', 'beautyzone') ,
                        'subtitle' => esc_html__('Upload your logo (272 x 90px) .png or .jpg', 'beautyzone') ,
                        'default' => array(
                            'url' => get_template_directory_uri() . '/assets/images/logo.png'
                        )
                    ) ,
                    array(
                        'id' => 'site_other_logo',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Other Logo', 'beautyzone') ,
                        'subtitle' => esc_html__('Upload your logo (272 x 90px) .png or .jpg', 'beautyzone') ,
                        'default' => array(
                            'url' => get_template_directory_uri() . '/assets/images/logo-2.png'
                        )
                    ) ,

                    array(
                        'id' => 'logo-section-end',
                        'type' => 'section',
                        'indent' => false,
                    ) ,
                )
            );

            /*--------------------------------------------------------------
            # 3. Header Settings
            --------------------------------------------------------------*/
            $header_social_links = $header_social_defaults = array();

            foreach ($this->social_link_options as $social_link)
            {

                $link_value = beautyzone_get_opt('social_' . $social_link['id'] . '_url');

                if (!empty($link_value))
                {
                    $header_social_links[$social_link['id']] = $social_link['title'];
                    $header_social_defaults[$social_link['id']] = false;
                }
            }

            $header_style_options = beautyzone_header_style_options();
            $header_aditional_array = array();
            $mobile_header_aditional_array = array();
            foreach ($header_style_options as $header)
            {
                $header_id = $header['id'];

                $header_social_defaults_1 = $header_social_defaults;

                $header_search_on = beautyzone_set($header['param'], 'search', false);
                $social_link = beautyzone_set($header['param'], 'social_link', false);
                $header_top_bar = beautyzone_set($header['param'], 'top_bar', false);
                $call_to_action_button = beautyzone_set($header['param'], 'call_to_action_button', 0);

                $total_links = beautyzone_set($header['param'], 'social_links', 0);
				
				
				
                if ($total_links > 0)
                {
                    $i = 1;
                    foreach ($header_social_links as $key => $value)
                    {
                        if ($i <= $total_links)
                        {
                            $header_social_defaults_1[$key] = 1;
                        }
                        else
                        {
                            $header_social_defaults_1[$key] = 0;
                        }
                        $i++;
                    }
                }
				
				
				$header_aditional_array[] = array(
					'id'    => $header_id . '_information',
					'type'  => 'info',
					'style' => 'success',
					'title' => esc_html__('Header Information!', 'beautyzone'),
					'icon'  => 'el-icon-info-sign',
					'desc'  => $header_id.' '.esc_html__( 'header settings display here.', 'beautyzone'),
					'required' => array(
                        0 => 'header_style',
                        1 => 'equals',
                        2 => $header_id
                    )
				);
				
                $header_aditional_array[] = array(
                    'id' => $header_id . '_top_bar_on',
                    'type' => 'switch',
                    'title' => esc_html__('Top Bar', 'beautyzone') ,
                    'subtitle' => esc_html__('Show or hide the top bar.', 'beautyzone') ,
                    'on' => esc_html__('Enabled', 'beautyzone') ,
                    'off' => esc_html__('Disabled', 'beautyzone') ,
                    'default' => $header_top_bar,
                    'required' => array(
                        0 => 'header_style',
                        1 => 'equals',
                        2 => $header_id
                    )
                );

                $header_aditional_array[] = array(
                    'id' => $header_id . '_phone',
                    'type' => 'text',
                    'title' => esc_html__('Phone', 'beautyzone') ,
                    'desc' => esc_html__('Please Enter Site Phone Number', 'beautyzone') ,
                    'default' => '001 1234 6789',
                    'required' => array(
                        array(
                            0 => 'header_style',
                            1 => 'equals',
                            2 => $header_id
                        ) ,
                        array(
                            0 => $header_id . '_top_bar_on',
                            1 => 'equals',
                            2 => 1
                        )
                    )
                );

                $header_aditional_array[] = array(
                    'id' => $header_id . '_address',
                    'type' => 'text',
                    'title' => esc_html__('Address', 'beautyzone') ,
                    'desc' => esc_html__('Please Enter Site Address', 'beautyzone') ,
                    'default' => esc_html__('6701 Democracy Blvd, Suite 300, USA', 'beautyzone') ,
                    'required' => array(
                        array(
                            0 => 'header_style',
                            1 => 'equals',
                            2 => $header_id
                        ) ,
                        array(
                            0 => $header_id . '_top_bar_on',
                            1 => 'equals',
                            2 => 1
                        )
                    )
                );

                $header_aditional_array[] = array(
                    'id' => $header_id . '_social_link_on',
                    'type' => 'switch',
                    'title' => esc_html__('Social Link', 'beautyzone') ,
                    'subtitle' => esc_html__('Show or hide the header social link option.', 'beautyzone') ,
                    'on' => esc_html__('Enabled', 'beautyzone') ,
                    'off' => esc_html__('Disabled', 'beautyzone') ,
                    'default' => $social_link,
                    'required' => array(
                        array(
                            0 => 'header_style',
                            1 => 'equals',
                            2 => $header_id
                        ) ,
                    )
                );

                if(!empty($header_social_links)) {
                $header_aditional_array[] = array(
                    'id' => $header_id . '_social_links',
                    'type' => 'checkbox',
                    'title' => esc_html__('Choose for this Header', 'beautyzone') ,
                    'subtitle' => esc_html__('No validation can be done on this field type', 'beautyzone') ,
                    'desc' => esc_html__('Check social icon as you want to show on your website', 'beautyzone') ,
                    //Must provide key => value pairs for multi checkbox options
                    'options' => $header_social_links,
                    //See how std has changed? you also don't need to specify opts that are 0.
                    'default' => $header_social_defaults_1,
                    'required' => array(
                        array(
                            0 => 'header_style',
                            1 => 'equals',
                            2 => $header_id
                        ) ,
                        array(
                            0 => $header_id . '_social_link_on',
                            1 => 'equals',
                            2 => 1
                        )
                    )
                );
				}

                $header_aditional_array[] = array(
                    'id' => $header_id . '_social_links',
                    'type' => 'checkbox',
                    'title' => esc_html__('Choose for this Header', 'beautyzone') ,
                    'subtitle' => esc_html__('No validation can be done on this field type', 'beautyzone') ,
                    'desc' => esc_html__('Check social icon as you want to show on your website.', 'beautyzone') ,
                    //Must provide key => value pairs for multi checkbox options
                    'options' => $header_social_links,
                    //See how std has changed? you also don't need to specify opts that are 0.
                    'default' => $header_social_defaults_1,
                    'required' => array(
                        array(
                            0 => 'header_style',
                            1 => 'equals',
                            2 => $header_id
                        ) ,
                        array(
                            0 => $header_id . '_social_link_on',
                            1 => 'equals',
                            2 => 1
                        )
                    )
                );

                if ($header_id == 'header_6')
                {

                    $header_aditional_array[] = array(
                        'id' => $header_id . '_contact_title',
                        'type' => 'text',
                        'title' => esc_html__('Contact Title', 'beautyzone') ,
                        'desc' => esc_html__('Enter contact title', 'beautyzone') ,
                        'default' => esc_html__('Call Us', 'beautyzone') ,
                        'required' => array(
                            array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            ) ,
                        )
                    );
                    $header_aditional_array[] = array(
                        'id' => $header_id . '_contact_number',
                        'type' => 'text',
                        'title' => esc_html__('Contact Number', 'beautyzone') ,
                        'desc' => esc_html__('Enter contact number', 'beautyzone') ,
                        'default' => '+141 0800-123456',
                        'required' => array(
                            array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            ) ,
                        )
                    );

                    $header_aditional_array[] = array(
                        'id' => $header_id . '_email_title',
                        'type' => 'text',
                        'title' => esc_html__('Email Title', 'beautyzone') ,
                        'desc' => esc_html__('Enter emali title.', 'beautyzone') ,
                        'default' => esc_html__('SEND US A MAIL', 'beautyzone') ,
                        'required' => array(
                            array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            ) ,
                        )
                    );
                    $header_aditional_array[] = array(
                        'id' => $header_id . '_contact_email',
                        'type' => 'text',
                        'title' => esc_html__('Contact Email', 'beautyzone') ,
                        'desc' => esc_html__('Enter emali', 'beautyzone') ,
                        'default' => esc_html__('info@dexignzone.com', 'beautyzone'),
                        'required' => array(
                            array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            ) ,
                        )
                    );

                    $header_aditional_array[] = array(
                        'id' => $header_id . '_opening_timing_title',
                        'type' => 'text',
                        'title' => esc_html__('Opening Timing Title', 'beautyzone') ,
                        'desc' => esc_html__('Enter timing title.', 'beautyzone') ,
                        'default' => esc_html__('OPENING TIME', 'beautyzone') ,
                        'required' => array(
                            array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            ) ,
                        )
                    );
                    $header_aditional_array[] = array(
                        'id' => $header_id . '_opening_timing',
                        'type' => 'text',
                        'title' => esc_html__('Office Timing', 'beautyzone') ,
                        'desc' => esc_html__('Enter office timing', 'beautyzone') ,
                        'default' => esc_html__('Mon -Sat: 7:00 - 17:00', 'beautyzone'),
                        'required' => array(
                            array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            ) ,
                        )
                    );

                    $header_aditional_array[] = array(
                        'id' => $header_id . '_call_button_title',
                        'type' => 'text',
                        'title' => esc_html__('Call Button Title', 'beautyzone') ,
                        'desc' => esc_html__('Enter call button title.', 'beautyzone') ,
                        'default' => esc_html__('CALL TOLL FREE', 'beautyzone') ,
                        'required' => array(
                            array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            ) ,
                        )
                    );
                    $header_aditional_array[] = array(
                        'id' => $header_id . '_call_button_number',
                        'type' => 'text',
                        'title' => esc_html__('Enter Number', 'beautyzone') ,
                        'desc' => esc_html__('Enter call button number.', 'beautyzone') ,
                        'default' => '+91 123 456 7890',
                        'required' => array(
                            array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            ) ,
                        )
                    );
                }

                if ($call_to_action_button > 0)
                {
                    for ($i = 1;$i <= $call_to_action_button;$i++)
                    {
                        $header_aditional_array[] = array(
                            'id' => $header_id . '_button_' . $i . '_text',
                            'type' => 'text',
                            'title' => esc_html__('Button ', 'beautyzone') . $i . esc_html__(' Text', 'beautyzone') ,
                            'default' => '',
                            'required' => array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            )
                        );
                        $header_aditional_array[] = array(
                            'id' => $header_id . '_button_' . $i . '_url',
                            'type' => 'text',
                            'title' => esc_html__('Button ', 'beautyzone') . $i . esc_html__(' URL', 'beautyzone') ,
                            'default' => '',
                            'required' => array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            )

                        );
                        $header_aditional_array[] = array(
                            'id' => $header_id . '_button_' . $i . '_target',
                            'type' => 'select',
                            'title' => esc_html__('Choose Button ', 'beautyzone') . $i . esc_html__(' Target', 'beautyzone') ,
                            'options' => $this->link_target_options,
                            'default' => '_blank',
                            'required' => array(
                                0 => 'header_style',
                                1 => 'equals',
                                2 => $header_id
                            )
                        );
                    }
                }

                $mobile_header_aditional_array[] = array(
                    'id' => $header_id . '_mobile_social_link_on',
                    'type' => 'switch',
                    'title' => esc_html__('Header Social Link', 'beautyzone') ,
                    'subtitle' => esc_html__('Show or hide the hader social link option.', 'beautyzone') ,
                    'on' => esc_html__('Enabled', 'beautyzone') ,
                    'off' => esc_html__('Disabled', 'beautyzone') ,
                    'default' => $social_link,
                    'required' => array(
                        0 => 'header_style',
                        1 => 'equals',
                        2 => $header_id
                    )
                );
                /******Header Related Fields *****/
            }

            $headerDefaultOption = array(
                'title' => esc_html__('Header Settings', 'beautyzone') ,
                'desc' => esc_html__('Describe header settings here.....................', 'beautyzone') ,
                'icon' => 'fa fa-header',
                'fields' => array(
                    array(
                        'id' => 'header_style',
                        'type' => 'image_select',
                        'title' => esc_html__('Header Style', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose header style. White header is set as default header for all theme.', 'beautyzone') ,
                        'options' => $this->header_style_options,
                        'default' => 'header_2',
                        'hint' => array(
                            array(
                                'title' => esc_html__('Choose Header Style', 'beautyzone'),
                                'content' => esc_html__('Choose default header Style as you want to display in your theme', 'beautyzone')
                            )
                        )
                    ) ,
                    

                    array(
                        'id' => 'header_login_on',
                        'type' => 'switch',
                        'title' => esc_html__('Login', 'beautyzone') ,
                        'subtitle' => esc_html__('Show or hide the header login option.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false
                    ) ,
                    array(
                        'id' => 'header_register_on',
                        'type' => 'switch',
                        'title' => esc_html__('Register', 'beautyzone') ,
                        'subtitle' => esc_html__('Show or hide the header register option.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false,
                    ) ,
                    array(
                        'id' => 'header_sticky_on',
                        'type' => 'switch',
                        'title' => esc_html__('Sticky Header', 'beautyzone') ,
                        'subtitle' => esc_html__('Header will be sticked when applicable.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false
                    ) ,
                    array(
                        'id' => 'mobile_section_start',
                        'type' => 'section',
                        'title' => esc_html__('Mobile Device Options', 'beautyzone') ,
                        'indent' => false
                    ) ,
                    array(
                        'id' => 'mobile_header_login_on',
                        'type' => 'switch',
                        'title' => esc_html__('Login', 'beautyzone') ,
                        'subtitle' => esc_html__('Show or hide the header login option.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false
                    ) ,
                    array(
                        'id' => 'mobile_header_register_on',
                        'type' => 'switch',
                        'title' => esc_html__('Register', 'beautyzone') ,
                        'subtitle' => esc_html__('Show or hide the header register option.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false
                    ) ,
                )
            );

            array_splice($headerDefaultOption['fields'], 4, 0, $header_aditional_array);
            $mobileFieldPosition = count($headerDefaultOption['fields']);
            array_splice($headerDefaultOption['fields'], $mobileFieldPosition, 0, $mobile_header_aditional_array);

            $this->sections[] = $headerDefaultOption;

            /*--------------------------------------------------------------
            # 4. Footer
            --------------------------------------------------------------*/
            $all_widgets = $this->beautyzone_get_wp_widgets();
            $footer_style_options = beautyzone_footer_style_options();

            $footer_setting_fields[] = array(
                'id' => 'footer_on',
                'type' => 'switch',
                'title' => esc_html__('Footer', 'beautyzone') ,
                'on' => esc_html__('Enabled', 'beautyzone') ,
                'off' => esc_html__('Disabled', 'beautyzone') ,
                'default' => true
            );
            $footer_setting_fields[] = array(
                'id' => 'footer_style',
                'type' => 'image_select',
                'title' => esc_html__('Footer Template', 'beautyzone') ,
                'subtitle' => esc_html__('Choose a template for footer.', 'beautyzone') ,
                'options' => $this->footer_style_options,
                'default' => 'footer_template_1',
                'required' => array(
                    0 => 'footer_on',
                    1 => 'equals',
                    2 => '1'
                )
            );

            foreach ($footer_style_options as $footer)
            {
                $footer_id = $footer['id'];
                $call_to_action_button = beautyzone_set($footer['param'], 'call_to_action_button', 0);
                $informative_fields = beautyzone_set($footer['param'], 'informative_field', 0);

                $footer_setting_fields[] = array(
                    'id' => $footer_id . '_bg_img',
                    'type' => 'media',
                    'title' => esc_html__('Footer Background Image', 'beautyzone') ,
                    'subtitle' => esc_html__('Choose background image for footer.', 'beautyzone') ,
                    'required' => array(
                        0 => 'footer_style',
                        1 => 'equals',
                        2 => $footer_id
                    )
                );

                if ($call_to_action_button > 0)
                {
                    for ($i = 1;$i <= $call_to_action_button;$i++)
                    {

                        $footer_setting_fields[] = array(
                            'id' => $footer_id . '_button_' . $i . '_text',
                            'type' => 'text',
                            'title' => esc_html__('Button ', 'beautyzone') . $i . esc_html__(' Text', 'beautyzone') ,
                            'default' => '',
                            'required' => array(
                                0 => 'footer_style',
                                1 => 'equals',
                                2 => $footer_id
                            )
                        );
                        $footer_setting_fields[] = array(
                            'id' => $footer_id . '_button_' . $i . '_url',
                            'type' => 'text',
                            'title' => esc_html__('Button ', 'beautyzone') . $i . esc_html__(' URL', 'beautyzone') ,
                            'default' => '',
                            'required' => array(
                                0 => 'footer_style',
                                1 => 'equals',
                                2 => $footer_id
                            )

                        );
                        $footer_setting_fields[] = array(
                            'id' => $footer_id . '_button_' . $i . '_target',
                            'type' => 'select',
                            'title' => esc_html__('Choose Button ', 'beautyzone') . $i . esc_html__(' Target', 'beautyzone') ,
                            'options' => $this->link_target_options,
                            'default' => '_self',
                            'required' => array(
                                0 => 'footer_style',
                                1 => 'equals',
                                2 => $footer_id
                            )
                        );
                    }
                }

                if ($informative_fields > 0)
                {
                    for ($i = 1;$i <= $informative_fields;$i++)
                    {

                        $footer_setting_fields[] = array(
                            'id' => $footer_id . '_info_field_' . $i . '_text',
                            'type' => 'text',
                            'title' => esc_html__('Field ', 'beautyzone') . $i . esc_html__(' Title', 'beautyzone') ,
                            'default' => '',
                            'required' => array(
                                0 => 'footer_style',
                                1 => 'equals',
                                2 => $footer_id
                            )
                        );
                        $footer_setting_fields[] = array(
                            'id' => $footer_id . '_info_field_' . $i . '_content',
                            'type' => 'textarea',
                            'title' => esc_html__('Field ', 'beautyzone') . $i . esc_html__(' Content', 'beautyzone') ,
                            'default' => '',
                            'required' => array(
                                0 => 'footer_style',
                                1 => 'equals',
                                2 => $footer_id
                            )

                        );
                    }
                }

            }

            $footer_style_options = beautyzone_footer_style_options();
            $total_footer = count($this->footer_style_options);

            $footer_block = array();
            $footer_block['All Widgets'] = $all_widgets;
            foreach ($footer_style_options as $key => $value)
            {
                $footer_id = $value['id'];

                if ($value['param']['copyright'] == 1)
                {

                }

                if ($value['param']['powered_by'] == 1)
                {

                }

            }

            $footer_setting_fields[] = array(
                'id' => 'footer_copyright_text',
                'type' => 'text',
                'title' => esc_html__('Copyright Text', 'beautyzone') ,
                'subtitle' => esc_html__('Write footer copyright text here.', 'beautyzone') ,
                'default' => esc_html__('© 2021', 'beautyzone') ,
                'required' => array(
                    0 => 'footer_on',
                    1 => 'equals',
                    2 => '1'
                )
            );
            $footer_setting_fields[] = array(
                'id' => 'footer_gallery_on',
                'type' => 'switch',
                'title' => esc_html__('Footer Gallery', 'beautyzone') ,
                'on' => esc_html__('Enabled', 'beautyzone') ,
                'off' => esc_html__('Disabled', 'beautyzone') ,
                'default' => false,
                'required' => array(
                    0 => 'footer_on',
                    1 => 'equals',
                    2 => '1'
                )
            );
            $footer_setting_fields[] = array(
                'id' => 'footer_gallery',
                'type' => 'gallery',
                'title' => esc_html__('Add/Edit Gallery', 'beautyzone') ,
                'subtitle' => esc_html__('Create a new Gallery by selecting existing or uploading new images using the WordPress native uploader', 'beautyzone') ,
                'required' => array(
                    0 => 'footer_gallery_on',
                    1 => 'equals',
                    2 => '1'
                )
            );

            $footer_setting_fields[] = array(
                'id' => 'footer_company_text',
                'type' => 'textarea',
                'title' => esc_html__('Company Text', 'beautyzone') ,
                'subtitle' => esc_html__('Write footer copyright text here.', 'beautyzone') ,
                'default' => esc_html__('All Rights Reserved.', 'beautyzone') ,
                'required' => array(
                    0 => 'footer_on',
                    1 => 'equals',
                    2 => '1'
                )
            );

            $this->sections[] = array(
                'title' => esc_html__('Footer Settings', 'beautyzone') ,
                'desc' => esc_html__('The footer uses widgets to show information. Here you can customize the number of layouts. In order to add widgets to the footer go to footer widgets section and drag widget to the footer block (s).', 'beautyzone') . '<br><br>' . esc_html__('Footer blocks are change according to footer templates.', 'beautyzone') ,
                'icon' => 'fa fa-home',
                'fields' => $footer_setting_fields
            );
			
			 /*--------------------------------------------------------------
            # 5. Menu Settings
            --------------------------------------------------------------*/
			$this->sections[] = array(
                'title' => esc_html__('Menu Settings', 'beautyzone') ,
                'icon' => 'el el-cog',
                'fields' => array(
                    array(
                        'id' => 'scroll_menu_pages',
                        'type' => 'select',
                        'data' => 'pages',
						'multi'=>true,
                        'title' => esc_html__('Choose Scroll Menu Pages', 'beautyzone') ,
                        'subtitle' => esc_html__('Select Page For One Page Menus', 'beautyzone') ,
                   
                    ) ,
                )
            );
            
            /*--------------------------------------------------------------
            # 5. Post Setting
            --------------------------------------------------------------*/
            $this->sections[] = array(
                'title' => esc_html__('Post Settings', 'beautyzone') ,
                'icon' => 'fa fa-newspaper-o'
            );

            $this->sections[] = array(
                'title' => esc_html__('General Settings', 'beautyzone') ,
                'desc' => esc_html__('This option will work on all new post and edit post sections. On new post page we will display only Post Layout Selection , all other settings will be applicable from here.', 'beautyzone') ,
                'subsection' => true,
                'icon' => 'fa fa-gear',
                'fields' => array(
                    array(
                        'id' => 'post_general_layout',
                        'type' => 'image_select',
                        'height' => '100',
                        'title' => esc_html__('Single Post Layout', 'beautyzone') ,
                        'subtitle' => esc_html__('Select a layout for post page.', 'beautyzone') ,
                        'desc' => esc_html__('Click on the template icon to select.', 'beautyzone') ,
                        'options' => $this->post_layouts_options,
                        'default' => 'standard',
                        'hint' => array(
                            'title' => esc_html__('How it Works?', 'beautyzone') ,
                            'content' => esc_html__('Once you select the template from here the template will apply for default post page.', 'beautyzone')
                        )
                    ) ,
                    array(
                        'id' => 'date_on',
                        'type' => 'switch',
                        'title' => esc_html__('Date', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true
                    ) ,
                    array(
                        'id' => 'comment_count_on',
                        'type' => 'switch',
                        'title' => esc_html__('Comment Count', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true
                    ) ,
                    array(
                        'id' => 'comment_view_on',
                        'type' => 'switch',
                        'title' => esc_html__('Comment View', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true
                    ) ,
                    array(
			            'id'       => 'post_view_on',
			            'type'     => 'switch',
			            'title'    => esc_html__('Post View', 'beautyzone'),
			            'on'       => esc_html__('Enabled', 'beautyzone'),
			            'off'       => esc_html__('Disabled', 'beautyzone'),
			            'default'  => false
			        ), 
                    array(
                        'id' => 'post_start_view',
                        'type' => 'text',
                        'title' => esc_html__('Post Start View', 'beautyzone') ,
                        'default' => '',
                        'desc' => esc_html__('Enter only number.', 'beautyzone') ,
                        'hint' => array(
                            'title' => esc_html__('Post Views', 'beautyzone') ,
                            'content' => esc_html__('We will display view count by adding this number in original post views. It will help to build post reputation on blog.', 'beautyzone')
                        )
                    ) ,
                    array(
                        'id' => 'author_box_on',
                        'type' => 'switch',
                        'title' => esc_html__('Author Box', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false
                    ) ,
                    array(
                        'id' => 'category_on',
                        'type' => 'switch',
                        'title' => esc_html__('Category', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true
                    ) ,
                    
                    array(
                        'id' => 'pre_next_post_on',
                        'type' => 'switch',
                        'title' => esc_html__('Previous & Next Post', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true
                    ) ,
                    array(
                        'id' => 'featured_img_on',
                        'type' => 'switch',
                        'title' => esc_html__('Featured Image', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true
                    ) ,
                   
                    array(
                        'id' => 'show_image_on_post_list',
                        'type' => 'switch',
                        'title' => esc_html__('Show Image On Post List', 'beautyzone') ,
                        'subtitle' => esc_html__('Show feature image on post listing in admin panel.', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false
                    ),
					array(
                        'id' => 'post_general_banner_on',
                        'type' => 'switch',
                        'title' => esc_html__('Post Banner', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false
                    ) ,
					
					array(
                        'id' => 'post-general-img-banner-section-start',
                        'type' => 'section',
                        'title' => esc_html__('Banner Setting', 'beautyzone') ,
                        'indent' => true,
						'required' => array(
                            0 => 'post_general_banner_on',
                            1 => 'equals',
                            2 => 1
                        )

                    ) ,
                    array(
                        'id' => 'post_general_banner_height',
                        'type' => 'image_select',
                        'title' => esc_html__('Post Banner Height', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose the height for all post page banner. Default : Small Banner', 'beautyzone') ,
                        'height' => '40',
                        'options' => $this->page_banner_options,
                        'default' => 'page_banner_small',
                    ) ,
                    array(
                        'id' => 'post_general_banner',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Post Banner Image', 'beautyzone') ,
                        'subtitle' => esc_html__('Upload post banner image. It will work as default banner image for all posts', 'beautyzone') ,
                        'desc' => esc_html__('Upload banner image.', 'beautyzone') ,
                        'default' => '',
                    ) ,
                    array(
                        'id' => 'post-general-img-banner-section-end',
                        'type' => 'section',
                        'indent' => false,
						'required' => array(
                            0 => 'post_general_banner_on',
                            1 => 'equals',
                            2 => 1
                        )
                    ),
					
                    array(
                        'id' => 'post_bg_image_custom',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Custom Post Background Image', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose custom background image for post single page.', 'beautyzone') ,
                        'desc' => esc_html__('Upload background image.', 'beautyzone') ,
                        'default' => array(
                            'url' => ''
                        ) ,
                        'required' => array(
                            0 => 'post_background_type',
                            1 => 'equals',
                            2 => 'custom'
                        ),
						'hint' => array(
                            'content' => 'If you upload custom background image than post banner image will not work.'
                        )
                    ) ,
                )
            );

            /*--------------------------------------------------------------
            # 6. Page Setting
            --------------------------------------------------------------*/

            $this->sections[] = array(
                'title' => esc_html__('Page Settings', 'beautyzone') ,
                'icon' => 'fa fa-file'
            );

            $this->sections[] = array(
                'title' => esc_html__('General Settings', 'beautyzone') ,
                'icon' => 'fa fa-gear',
                'desc' => '',
                'subsection' => true,
                'fields' => array(
                    array(
                        'id' => 'page_general_banner_on',
                        'type' => 'switch',
                        'title' => esc_html__('Page Banner', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true
                    ) ,
                    array(
                        'id' => 'page_general_banner_type',
                        'type' => 'button_set',
                        'title' => esc_html__('Page Banner Type', 'beautyzone') ,
                        'options' => $this->banner_type,
                        'default' => 'image',
                        'required' => array(
                            0 => 'page_general_banner_on',
                            1 => 'equals',
                            2 => '1'
                        )
                    ) ,
                    array(
                        'id' => 'general-img-banner-section-start',
                        'type' => 'section',
                        'title' => esc_html__('Image Banner Setting', 'beautyzone') ,
                        'indent' => true,
                        'required' => array(
                            0 => 'page_general_banner_type',
                            1 => 'equals',
                            2 => 'image'
                        )
                    ) ,
                    array(
                        'id' => 'page_general_banner_height',
                        'type' => 'image_select',
                        'title' => esc_html__('Page Banner Height', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose the height for all page banner. Default : Big Banner', 'beautyzone') ,
                        'height' => '40',
                        'options' => $this->page_banner_options,
                        'default' => 'page_banner_small',
                        'required' => array(
                            0 => 'page_general_banner_type',
                            1 => 'equals',
                            2 => 'image'
                        )
                    ) ,
                    array(
                        'id' => 'page_general_banner',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Page Banner Image', 'beautyzone') ,
                        'subtitle' => esc_html__('Upload page banner image. It will work as default banner image for all pages', 'beautyzone') ,
                        'desc' => esc_html__('Upload banner image.', 'beautyzone') ,
                        'default' => '',
                        'required' => array(
                            0 => 'page_general_banner_type',
                            1 => 'equals',
                            2 => 'image'
                        )
                    ) ,
                    array(
                        'id' => 'general-img-banner-section-end',
                        'type' => 'section',
                        'indent' => false,
                    ) ,
                    array(
                        'id' => 'general-post-banner-section-start',
                        'type' => 'section',
                        'title' => esc_html__('Post Banner Setting', 'beautyzone') ,
                        'indent' => true,
                        'required' => array(
                            0 => 'page_general_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => 'page_general_no_of_post',
                        'type' => 'text',
                        'title' => esc_html__('Number of Posts', 'beautyzone') ,
                        'subtitle' => esc_html__('Enter number of post. Default : 3', 'beautyzone') ,
                        'default' => '3',
                        'required' => array(
                            0 => 'page_general_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => 'general_post_banner_layout',
                        'type' => 'image_select',
                        'title' => esc_html__('Post Banner Layout', 'beautyzone') ,
                        'subtitle' => esc_html__('Select banner layout. Default : Full Banner', 'beautyzone') ,
                        'options' => $this->post_banner_options,
                        'default' => 'post_banner_v1',
                        'required' => array(
                            0 => 'page_general_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => 'page_general_banner_cat',
                        'type' => 'select',
                        'multi' => true,
                        'data' => 'terms',
                        'args' => array(
                            'taxonomies' => 'category'
                        ) ,
                        'title' => esc_html__('Post Category', 'beautyzone') ,
                        'subtitle' => esc_html__('Select post category. It will work as default banner for all pages', 'beautyzone') ,
                        'desc' => esc_html__('Allow you to select multiple categories.', 'beautyzone') ,
                        'default' => '',
                        'required' => array(
                            0 => 'page_general_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => 'page_general_post_type',
                        'type' => 'button_set',
                        'title' => esc_html__('Post Type', 'beautyzone') ,
                        'options' => array(
                            'all' => esc_html__('All', 'beautyzone') ,
                            'featured' => esc_html__('Featured', 'beautyzone')
                        ) ,
                        'default' => 'all',
                        'force_output' => true,
                        'required' => array(
                            0 => 'page_general_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => 'page_general_items_with',
                        'type' => 'button_set',
                        'title' => esc_html__('Items With', 'beautyzone') ,
                        'options' => array(
                            'with_any_type' => esc_html__('Any Type', 'beautyzone') ,
                            'with_featured_image' => esc_html__('With Featured Image', 'beautyzone') ,
                            'without_featured_image' => esc_html__('Without Featured Iimage', 'beautyzone')
                        ) ,
                        'default' => 'with_any_type',
                        'required' => array(
                            0 => 'page_general_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => 'general-post-banner-section-end',
                        'type' => 'section',
                        'indent' => false,
                    ) ,
                    array(
                        'id' => 'general-sidebar-section-start',
                        'type' => 'section',
                        'title' => esc_html__('Sidebar Setting', 'beautyzone') ,
                        'indent' => true
                    ) ,
                    array(
                        'id' => 'page_general_show_sidebar',
                        'type' => 'switch',
                        'title' => esc_html__('Sidebar', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => beautyzone_get_opt('show_sidebar')
                    ) ,
                    array(
                        'id' => 'page_general_sidebar_layout',
                        'type' => 'image_select',
                        'title' => esc_html__('Sidebar Layout', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose the layout for page. (Default : Right Side).', 'beautyzone') ,
                        'options' => $this->sidebar_layout_options,
                        'default' => 'right',
                        'required' => array(
                            0 => 'page_general_show_sidebar',
                            1 => 'equals',
                            2 => '1'
                        )
                    ) ,
                    array(
                        'id' => 'page_general_sidebar',
                        'type' => 'select',
                        'data' => 'sidebars',
                        'title' => esc_html__('Sidebar', 'beautyzone') ,
                        'subtitle' => esc_html__('Select sidebar for all pages', 'beautyzone') ,
                        'default' => 'dz_default_sidebar',
                        'required' => array(
                            0 => 'page_general_sidebar_layout',
                            1 => 'equals',
                            2 => array(
                                'right',
                                'left'
                            )
                        )
                    ) ,
                    array(
                        'id' => 'general-sidebar-section-end',
                        'type' => 'section',
                        'indent' => false,
                    ) ,
                    array(
                        'id' => 'page_general_paging',
                        'type' => 'button_set',
                        'title' => esc_html__('Pagination', 'beautyzone') ,
                        'options' => array(
                            'default' => esc_html__('Default', 'beautyzone') ,
                            'load_more' => esc_html__('Load More', 'beautyzone') ,
                            
                            
                        ) ,
                        'default' => 'default',
                        'force_output' => true
                    ) ,
                    

                )
            );

            $default_pages_data = array(
                'page_author' => array(
                    'top_desc' => esc_html__('The author template is shown when a user clicks on the author in the front end of the site.', 'beautyzone'),
                    'id' => 'author',
                    'title' => esc_html__('Author', 'beautyzone'),
                    'icon' => 'fa fa-user'
                ) ,
                'page_category' => array(
                    'top_desc' => esc_html__('The category template is shown when a user clicks on the category in the front end of the site.', 'beautyzone'),
                    'id' => 'category',
                    'title' => esc_html__('Category', 'beautyzone'),
                    'icon' => 'fa fa-list-alt'
                ) ,
                'page_search' => array(
                    'top_desc' => esc_html__('Set the default layout for all the search page.', 'beautyzone'),
                    'id' => 'search',
                    'title' => esc_html__('Search', 'beautyzone'),
                    'icon' => 'fa fa-search'
                ) ,
                'page_archive' => array(
                    'top_desc' => esc_html__('This template is used by WordPress to generate the archives. By default WordPress generates daily, monthly and yearly archives.', 'beautyzone'),
                    'id' => 'archive',
                    'title' => esc_html__('Archive', 'beautyzone'),
                    'icon' => 'fa fa-archive'
                ) ,
                'page_tag' => array(
                    'top_desc' => esc_html__('Set the default layout for all the tag page.', 'beautyzone'),
                    'id' => 'tag',
                    'title' => esc_html__('Tag', 'beautyzone'),
                    'icon' => 'fa fa-tags'
                ) ,

            );

            if (beautyzone_is_woocommerce_active())
            {
                $default_pages_data['page_woocommerce'] = array(
                    'top_desc' => esc_html__('Set the default layout for all the woo-commerce pages.', 'beautyzone'),
                    'id' => 'woocommerce',
                    'title' => esc_html__('WooCommerce', 'beautyzone'),
                    'icon' => 'fa fa-shopping-cart',
                    'sidebar' => 'dz_shop_sidebar'
                );
            }

            foreach ($default_pages_data as $key => $page_data)
            {

                $pg_desc = $page_data['top_desc'];
                $pg_id = $page_data['id'];
                $pg_name = $page_data['title'];
                $pg_icon = $page_data['icon'];
                $pg_sidebar = !empty($page_data['sidebar']) ? $page_data['sidebar'] : 'dz_default_sidebar';

                if ($key == 'page_cmsoon')
                {
                    $page_templates = $this->coming_template_options;
                }
                elseif ($key == 'page_maintenance')
                {
                    $page_templates = $this->maintenance_template_options;
                }
                else
                {
                    $page_templates = $this->page_template_options;
                }

                $page_default_settings = $page_sorting = $page_pagination = array();

                $page_default_settings = array(
                    array(
                        'id' => $pg_id . '_page_title',
                        'type' => 'text',
                        'title' => esc_html__('Page Title', 'beautyzone') ,
                        'default' => $pg_name . esc_html__(' : ', 'beautyzone') ,
                        'force_output' => true
                    ) ,
                    array(
                        'id' => $pg_id . '_page_banner_on',
                        'type' => 'switch',
                        'title' => esc_html__('Page Banner', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false
                    ) ,

                    array(
                        'id' => $pg_id . '_page_banner_type',
                        'type' => 'button_set',
                        'title' => esc_html__('Page Banner Type', 'beautyzone') ,
                        'options' => $this->banner_type,
                        'default' => 'image',
                        'required' => array(
                            0 => $pg_id . '_page_banner_on',
                            1 => 'equals',
                            2 => '1'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '-img-banner-section-start',
                        'type' => 'section',
                        'title' => esc_html__('Image Banner Setting', 'beautyzone') ,
                        'indent' => true,
                        'required' => array(
                            0 => $pg_id . '_page_banner_type',
                            1 => 'equals',
                            2 => 'image'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '_page_banner_height',
                        'type' => 'image_select',
                        'title' => esc_html__('Page Banner Height', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose the height for page banner. Default : Big Banner', 'beautyzone') ,
                        'height' => '40',
                        'options' => $this->page_banner_options,
                        'default' => 'page_banner_small',
                        'required' => array(
                            0 => $pg_id . '_page_banner_type',
                            1 => 'equals',
                            2 => 'image'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '_page_banner_custom_height',
                        'type' => 'slider',
                        'title' => esc_html__('Page Banner Custom Height', 'beautyzone') ,
                        'desc' => esc_html__('Hight description. Min: 100, max: 800', 'beautyzone') ,
                        "min" => 100,
                        "max" => 800,
                        'display_value' => 'text',
                        'required' => array(
                            0 => $pg_id . '_page_banner_height',
                            1 => 'equals',
                            2 => 'page_banner_custom'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '_page_banner',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Page Banner Image', 'beautyzone') ,
                        'subtitle' => esc_html__('Upload page banner image. It will work as default banner image for the page.', 'beautyzone') ,
                        'desc' => esc_html__('Upload banner image.', 'beautyzone') ,
                       
                        'required' => array(
                            0 => $pg_id . '_page_banner_type',
                            1 => 'equals',
                            2 => 'image'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '_page_banner_hide',
                        'type' => 'checkbox',
                        'title' => esc_html__('Don`t use banner image for this page', 'beautyzone') ,
                        'default' => '0',
                        'desc' => esc_html__('Check if you don`t want to use banner image', 'beautyzone') ,
                        'required' => array(
                            0 => $pg_id . '_page_banner_type',
                            1 => 'equals',
                            2 => 'image'
                        ) ,
                        'hint' => array(
                            'content' => esc_html__('If we don`t have suitable image then we can hide current or default banner images and show only banner container with theme default color.', 'beautyzone')
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '-img-banner-section-end',
                        'type' => 'section',
                        'indent' => false,
                    ) ,
                    array(
                        'id' => $pg_id . '-post-banner-section-start',
                        'type' => 'section',
                        'title' => esc_html__('Post Banner Setting', 'beautyzone') ,
                        'indent' => true,
                        'required' => array(
                            0 => $pg_id . '_page_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '_page_no_of_post',
                        'type' => 'text',
                        'title' => esc_html__('Number of Posts', 'beautyzone') ,
                        'subtitle' => esc_html__('Enter number of post. Default : 3', 'beautyzone') ,
                        'default' => '3',
                        'required' => array(
                            0 => $pg_id . '_page_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '_post_banner_layout',
                        'type' => 'image_select',
                        'title' => esc_html__('Post Banner Layout', 'beautyzone') ,
                        'subtitle' => esc_html__('Select banner layout. Default : Full Banner', 'beautyzone') ,
                        'options' => $this->post_banner_options,
                        'default' => 'post_banner_v1',
                        'required' => array(
                            0 => $pg_id . '_page_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '_page_banner_cat',
                        'type' => 'select',
                        'multi' => true,
                        'data' => 'terms',
                        'args' => array(
                            'taxonomies' => 'category'
                        ) ,
                        'title' => esc_html__('Post Category', 'beautyzone') ,
                        'subtitle' => esc_html__('Select post category. It will work as default banner for the page.', 'beautyzone') ,
                        'desc' => esc_html__('Allow you to select multiple categories.', 'beautyzone') ,
                       
                        'required' => array(
                            0 => $pg_id . '_page_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '_page_post_type',
                        'type' => 'button_set',
                        'title' => esc_html__('Post Type', 'beautyzone') ,
                        'options' => array(
                            'all' => esc_html__('All', 'beautyzone') ,
                            'featured' => esc_html__('Featured', 'beautyzone')
                        ) ,
                        'default' => 'all',
                        'force_output' => true,
                        'required' => array(
                            0 => $pg_id . '_page_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '_page_items_with',
                        'type' => 'button_set',
                        'title' => esc_html__('Items With', 'beautyzone') ,
                        'options' => array(
                            'with_any_type' => esc_html__('Any Type', 'beautyzone') ,
                            'with_featured_image' => esc_html__('With Featured Image', 'beautyzone') ,
                            'without_featured_image' => esc_html__('Without Featured Iimage', 'beautyzone')
                        ) ,
                        'default' => 'with_any_type',
                        'required' => array(
                            0 => $pg_id . '_page_banner_type',
                            1 => 'equals',
                            2 => 'post'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '-post-banner-section-end',
                        'type' => 'section',
                        'indent' => false,
                    ) ,
                );

                $page_sorting = array(
                    array(
                        'id' => $pg_id . '-sidebar-section-start',
                        'type' => 'section',
                        'title' => esc_html__('Sidebar Setting', 'beautyzone') ,
                        'indent' => true
                    ) ,
                    array(
                        'id' => $pg_id . '_page_show_sidebar',
                        'type' => 'switch',
                        'title' => esc_html__('Sidebar', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => true
                    ) ,
                    array(
                        'id' => $pg_id . '_page_sidebar_layout',
                        'type' => 'image_select',
                        'title' => esc_html__('Sidebar Layout', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose the sidebar layout for the page. (Default : Right Side).', 'beautyzone') ,
                        'options' => $this->sidebar_layout_options,
                        'default' => 'right',
                        'required' => array(
                            0 => $pg_id . '_page_show_sidebar',
                            1 => 'equals',
                            2 => '1'
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '_page_sidebar',
                        'type' => 'select',
                        'data' => 'sidebars',
                        'title' => esc_html__('Sidebar', 'beautyzone') ,
                        'subtitle' => esc_html__('Select sidebar for the page.', 'beautyzone') ,
                        'default' => $pg_sidebar,
                        'required' => array(
                            0 => $pg_id . '_page_sidebar_layout',
                            1 => 'equals',
                            2 => array(
                                'right',
                                'left'
                            )
                        )
                    ) ,
                    array(
                        'id' => $pg_id . '-sidebar-section-end',
                        'type' => 'section',
                        'indent' => false,
                    ) ,
                );

                if ($pg_id != 'woocommerce')
                {
                    $page_pagination = array(
                        array(
                            'id' => $pg_id . '_page_paging',
                            'type' => 'button_set',
                            'title' => esc_html__('Pagination', 'beautyzone') ,
                            'options' => array(
                                'default' => esc_html__('Default', 'beautyzone') ,
                                'load_more' => esc_html__('Load More', 'beautyzone') ,
                                
                            ) ,
                            'default' => 'default',
                            'force_output' => true
                        ) ,
                        array(
                            'id' => $pg_id . '_page_sorting_on',
                            'type' => 'switch',
                            'title' => esc_html__('Sorting', 'beautyzone') ,
                            'on' => esc_html__('Enabled', 'beautyzone') ,
                            'off' => esc_html__('Disabled', 'beautyzone') ,
                            'default' => true
                        ) ,
                        array(
                            'id' => $pg_id . '_page_sorting',
                            'type' => 'select',
                            'title' => esc_html__('Select Sorting', 'beautyzone') ,
                            'subtitle' => esc_html__('Select Sorting', 'beautyzone') ,
                            'desc' => esc_html__('Select Sorting', 'beautyzone') ,
                            'options' => $this->sort_by_options,
                            'default' => 'date_asc',
                            'force_output' => true,
                            'required' => array(
                                0 => $pg_id . '_page_sorting_on',
                                1 => 'equals',
                                2 => '1'
                            )
                        ) ,
                        

                    );
                }

                $final_page_options = array_merge($page_default_settings, $page_sorting, $page_pagination);

                $this->sections[] = array(
                    'title' => $pg_name . esc_html__(' Page', 'beautyzone') ,
                    'icon' => $pg_icon,
                    'desc' => '',
                    'subsection' => true,
                    'fields' => $final_page_options,
                );

            }

            $this->sections[] = array(
                'title' => esc_html__('404 Page', 'beautyzone') ,
                'icon' => 'fa fa-warning',
                'desc' => esc_html__('When a user requests a page or post that doesn`t exists, WordPress will use this template.', 'beautyzone'),
                'subsection' => true,
                'fields' => array(
                    array(
                        'id' => 'error_page_title',
                        'type' => 'text',
                        'title' => esc_html__('Page Title', 'beautyzone') ,
                        'default' => esc_html__('404', 'beautyzone') ,
                        'force_output' => true
                    ) ,
                    array(
                        'id' => 'error_page_subtitle',
                        'type' => 'text',
                        'title' => esc_html__('Page Subitle', 'beautyzone') ,
                        'default' => esc_html__('Oops!', 'beautyzone') ,
                        'force_output' => true
                    ) ,
					array(
			            'id'       => 'error_404_bg',
			            'type'     => 'media',
						'url'      => true,
			            'title'    => esc_html__('404 Page Background', 'beautyzone'),
			            'default'  => array(
			            'url'=> get_template_directory_uri() . '/assets/images/bg6.jpg'
			            ),
			        ),
					array(
			            'id'       => 'error_404_image',
			            'type'     => 'media',
						'url'      => true,
			            'title'    => esc_html__('404 Page Image', 'beautyzone'),
			            'default'  => array(
			            'url'=> get_template_directory_uri() . '/assets/images/collage.png'
			            ),
			        ),
                    array(
                        'id' => 'error_page_template',
                        'type' => 'image_select',
                        'height' => '80',
                        'title' => esc_html__('404 Template', 'beautyzone') ,
                        'subtitle' => esc_html__('Select a template for the page.', 'beautyzone') ,
                        'options' => array(
                            'error_style_1' => get_template_directory_uri() . '/dz-inc/assets/images/page-template/error-404.png'
                        ) ,
                        'default' => 'error_style_1'
                    ) ,
                    array(
                        'id' => 'error_page_text',
                        'type' => 'textarea',
                        'title' => esc_html__('404 Page Text', 'beautyzone') ,
                        'default' => esc_html__('Page Not Found', 'beautyzone')
                    ) ,
                    array(
                        'id' => 'error_page_button_text',
                        'type' => 'text',
                        'title' => esc_html__('404 Page Button Text', 'beautyzone') ,
                        'default' => esc_html__('Back to Home', 'beautyzone')
                    ) ,
                )
            );

            /*--------------------------------------------------------------
            # 15. WooCommerce Setting
            --------------------------------------------------------------*/
            if (beautyzone_is_woocommerce_active())
            {
                $this->sections[] = array(
                    'title' => esc_html__('WooCommerce Settings', 'beautyzone') ,
                    'icon' => 'el el-shopping-cart'
                );

                $this->sections[] = array(
                    'title' => esc_html__('WooCommerce', 'beautyzone') ,
                    'icon' => 'fa fa-shopping-basket',
                    'subsection' => true,
                    'fields' => array(
						array(
							'id' => 'woocommerce_page_section_heading',
							'type' => 'text',
							'title' => esc_html__('WooCommerce Section Heading', 'beautyzone') ,
							'default' => esc_html__('Latest Product', 'beautyzone')
						) ,
                        array(
                            'id' => 'cart_on',
                            'type' => 'switch',
                            'title' => esc_html__('Cart Enable', 'beautyzone') ,
                            'subtitle' => esc_html__('Click on the tab to show / hide cart from header.', 'beautyzone') ,
                            'on' => esc_html__('Enabled', 'beautyzone') ,
                            'off' => esc_html__('Disabled', 'beautyzone') ,
                            'default' => true,
                            'hint' => array(
                                'title' => esc_html__('Cart Visible', 'beautyzone') ,
                                'content' => esc_html__('Cart will show in top bar.', 'beautyzone')
                            )
                        ) ,
                        array(
                            'id' => 'cart_on_mobile',
                            'type' => 'switch',
                            'title' => esc_html__('Cart On Mobile Enable', 'beautyzone') ,
                            'subtitle' => esc_html__('Click on the tab to show / hide cart in mobile view.', 'beautyzone') ,
                            'on' => esc_html__('Enabled', 'beautyzone') ,
                            'off' => esc_html__('Disabled', 'beautyzone') ,
                            'default' => true
                        ) ,
                        array(
                            'id' => 'no_of_product_per_page',
                            'type' => 'spinner',
                            'title' => esc_html__('Number of Product Display Per Page', 'beautyzone') ,
                            'subtitle' => esc_html__('Show number of product page', 'beautyzone') ,
                            'default' => 10,
                            'min' => 1,
                            'step' => 1,
                            'max' => 100,
                        ) ,
                        array(
                            'id' => 'no_of_product_column',
                            'type' => 'slider',
                            'title' => esc_html__('Product Columns', 'beautyzone') ,
                            'default' => 3,
                            'min' => 1,
                            'step' => 1,
                            'max' => 4,
                            'display_value' => 'label'
                        ) ,
                        array(
                            'id' => 'show_related_product',
                            'type' => 'switch',
                            'title' => esc_html__('Show Related Product', 'beautyzone') ,
                            'subtitle' => esc_html__('Click on the tab to show / hide related products on single product page.', 'beautyzone') ,
                            'on' => esc_html__('Enabled', 'beautyzone') ,
                            'off' => esc_html__('Disabled', 'beautyzone') ,
                            'default' => true
                        ) ,
                        array(
                            'id' => 'no_of_related_product',
                            'type' => 'slider',
                            'title' => esc_html__('Related Product', 'beautyzone') ,
                            'default' => 3,
                            'min' => 1,
                            'step' => 1,
                            'max' => 4,
                            'display_value' => 'label'
                        )
                    )
                );
            }

            /*--------------------------------------------------------------
            # 10. Theme Setting
            --------------------------------------------------------------*/
            $this->sections[] = array(
                'title' => esc_html__('Theme Settings', 'beautyzone') ,
                'icon' => 'el el-cogs'
            );

            $this->sections[] = array(
                'title' => esc_html__('Color & Design', 'beautyzone') ,
                'icon' => 'fa fa-pencil',
                'subsection' => true,
                'fields' => array(
                    array(
                        'id' => 'color_skin_setting',
                        'type' => 'button_set',
                        'title' => esc_html__('Theme Color Settings', 'beautyzone') ,
                        'desc' => esc_html__('Choose Color Setting', 'beautyzone') ,
                        'options' => array(
                            'predefined_color_skin' => esc_html__('Predefined Color', 'beautyzone') ,
                            'custom_color_skin' => esc_html__('Custom Color', 'beautyzone')
                        ) ,
                        'default' => 'predefined_color_skin',
						
                    ) ,
				
				
                    array(
                        'id' => 'predefined_color_skin',
                        'type' => 'image_select',
                        'title' => esc_html__('Theme Color', 'beautyzone') ,
                        'subtitle' => esc_html__('Only color validation can be done on this field type', 'beautyzone') ,
                        'options' => $this->theme_color_options,
                        'default' => 'pink',
                        'height' => '50',
						'required' => array(
                            0 => 'color_skin_setting',
                            1 => 'equals',
                            2 => 'predefined_color_skin'
                        )
                    ) ,
					
					array(
						'id'          => 'primary_color',
						'type'        => 'color',
						'title'       => esc_html__('Primary Color', 'beautyzone'),
						'transparent' => false,
						'default'     => '#ff5ea5',
						'required' => array(
                            0 => 'color_skin_setting',
                            1 => 'equals',
                            2 => 'custom_color_skin'
                        )
					),
					array(
						'id'          => 'secondary_color',
						'type'        => 'color',
						'title'       => esc_html__('Secondary Color', 'beautyzone'),
						'transparent' => false,
						'default'     => '#00becf',
						'required' => array(
                            0 => 'color_skin_setting',
                            1 => 'equals',
                            2 => 'custom_color_skin'
                        )
					),
					array(
						'id'      => 'link_color',
						'type'    => 'link_color',
						'title'   => esc_html__('Link Colors', 'beautyzone'),
						'default' => array(
							'regular' => '#ff5ea5',
							'hover'   => '#e54d90',
							'active'  => '#e54d90'
						),
						'output'  => array('a'),
						'required' => array(
                            0 => 'color_skin_setting',
                            1 => 'equals',
                            2 => 'custom_color_skin'
                        )
					),
                    array(
                        'id' => 'page_loader_type',
                        'type' => 'button_set',
                        'title' => esc_html__('Page Loader Type', 'beautyzone') ,
                        'subtitle' => esc_html__('Select Loader Type.', 'beautyzone') ,
                        'desc' => esc_html__('Choose Loading Image', 'beautyzone') ,
                        'options' => array(
                            'loading_image' => esc_html__('Loading Image', 'beautyzone') ,
                            'advanced_loader' => esc_html__('Advanced Page Loader', 'beautyzone')
                        ) ,
                        'default' => 'loading_image',
                        'hint' => array(
                            'title' => esc_html__('Write title text here', 'beautyzone') ,
                            'content' => esc_html__('Write content text here.', 'beautyzone')
                        )
                    ) ,
                    array(
                        'id' => 'page_loader_image',
                        'type' => 'image_select',
                        'title' => esc_html__('Loding Image (Gif)', 'beautyzone') ,
                        'subtitle' => esc_html__('Select Gif Image.', 'beautyzone') ,
                        'desc' => esc_html__('Choose Gif Image.', 'beautyzone') ,
                        'options' => $this->page_loader_options,
                        'default' => 'loading3',
                        'height' => '35',
                        'hint' => array(
                            'title' => esc_html__('Loding Image (Gif)', 'beautyzone') ,
                            'content' => esc_html__('Choose Gif Image.', 'beautyzone')
                        ) ,
                        'required' => array(
                            0 => 'page_loader_type',
                            1 => 'equals',
                            2 => 'loading_image'
                        )
                    ) ,
                    array(
                        'id' => 'custom_page_loader_image',
                        'type' => 'media',
                        'url' => true,
                        'title' => esc_html__('Custom Loding Image (Gif)', 'beautyzone') ,
                        'subtitle' => esc_html__('Select Custom Loding Gif Image.', 'beautyzone') ,
                        'desc' => esc_html__('Choose Gif Image', 'beautyzone') ,
                        'hint' => array(
                            'title' => esc_html__('Custom Loding Image (Gif)', 'beautyzone') ,
                            'content' => esc_html__('Choose Gif Image.', 'beautyzone')
                        ) ,
                        'required' => array(
                            0 => 'page_loader_type',
                            1 => 'equals',
                            2 => 'loading_image'
                        )
                    ) ,
                    array(
                        'id' => 'advanced_page_loader_image',
                        'type' => 'image_select',
                        'title' => esc_html__('Advanced Loding Image', 'beautyzone') ,
                        'subtitle' => esc_html__('Select Advance Loding Image (Gif)', 'beautyzone') ,
                        'desc' => esc_html__('Choose Advance Loding Image', 'beautyzone') ,
                        'options' => array(
                            'loading1' => get_template_directory_uri() . '/dz-inc/assets/images/advanced-loading-images/loading1.gif',
                            'loading2' => get_template_directory_uri() . '/dz-inc/assets/images/advanced-loading-images/loading2.gif',
                        ) ,
                        'default' => 'loading1',
                        'height' => '60',
                        'hint' => array(
                            'title' => esc_html__('Advance Loding Image (Gif)', 'beautyzone') ,
                            'content' => esc_html__('Choose Advance Loding Image', 'beautyzone')
                        ) ,
                        'required' => array(
                            0 => 'page_loader_type',
                            1 => 'equals',
                            2 => 'advanced_loader'
                        )
                    ) ,
                    array(
                        'id' => 'theme_layout',
                        'type' => 'image_select',
                        'title' => esc_html__('Theme Layout', 'beautyzone') ,
                        'subtitle' => esc_html__('Choose theme layout.', 'beautyzone') ,
                        'desc' => esc_html__('Click in the image icon to select the theme layout (Default : Full Width).', 'beautyzone') ,
                        'options' => $this->theme_layout_options,
                        'height' => '80',
                        'default' => 'theme_layout_1',
                        'hint' => array(
                            'title' => esc_html__('How it Works?', 'beautyzone') ,
                            'content' => esc_html__('1. Full Width: the web pages will be full width as shown in image.', 'beautyzone') . '<br><br>' . esc_html__('2. Boxed: with the box layout the padding will be apply on two sides (Left, Right) of the page.', 'beautyzone') . '<br><br>' . esc_html__('3. Frame: with the frame layout the padding will be apply on all the sides (Top, Right, Bottom, Left) of the page.', 'beautyzone')
                        )
                    ) ,
                    array(
                        'id' => 'boxed_layout_bg_pattern_padding',
                        'type' => 'slider',
                        'title' => esc_html__('Padding', 'beautyzone') ,
                        'desc' => esc_html__('Padding description. Min: 10, max: 100, default value: 20', 'beautyzone') ,
                        "default" => 20,
                        "min" => 10,
                        "max" => 100,
                        'display_value' => 'text',
                        'required' => array(
                            array(
                                0 => 'theme_layout',
                                1 => 'equals',
                                2 => 'theme_layout_3'
                            )
                        )
                    ) ,
                    array(
                        'id' => 'body_boxed_bg_type',
                        'type' => 'button_set',
                        'title' => esc_html__('Background Type', 'beautyzone') ,
                        'subtitle' => esc_html__('Select the background type.', 'beautyzone') ,
                        'desc' => esc_html__('Click on the tab to choose background type', 'beautyzone') ,
                        'options' => array(
                            'bg_type_color' => esc_html__('Type Color', 'beautyzone') ,
                            'bg_type_image' => esc_html__('Type Image', 'beautyzone') ,
                            'bg_type_pattern' => esc_html__('Type Pattern', 'beautyzone')
                        ) ,
                        'default' => 'bg_type_color',
                        'hint' => array(
                            'title' => esc_html__('How it Works?', 'beautyzone') ,
                            'content' => esc_html__('1. Type Color: page background will be type color.', 'beautyzone') . '<br><br>' . esc_html__('2. Type Image: page background will be type image.', 'beautyzone') . '<br><br>' . esc_html__('3. Type Pattern: page background will be type pattern.', 'beautyzone')
                        ) ,
                        'required' => array(
                            0 => 'theme_layout',
                            1 => 'equals',
                            2 => array(
                                'theme_layout_2',
                                'theme_layout_3'
                            )
                        )
                    ) ,
                    array(
                        'id' => 'boxed_layout_bg_color',
                        'type' => 'image_select',
                        'title' => esc_html__('Background Color', 'beautyzone') ,
                        'subtitle' => esc_html__('Select background color', 'beautyzone') ,
                        'desc' => esc_html__('Click on the image icon to choose background color.', 'beautyzone') ,
                        'options' => $this->theme_color_background_options,
                        'height' => '35',
                        'default' => 'bg_color_1',
                        'hint' => array(
                            'title' => esc_html__('Boxed layout Background Color', 'beautyzone') ,
                            'content' => esc_html__('choose this section If you want boxed layout background color.', 'beautyzone')
                        ) ,
                        'required' => array(
                            0 => 'body_boxed_bg_type',
                            1 => 'equals',
                            2 => 'bg_type_color'
                        )
                    ) ,
                    array(
                        'id' => 'boxed_layout_custom_bg_color',
                        'type' => 'color_rgba',
                        'title' => 'Custom Background Color',
                        'subtitle' => esc_html__('(Optional) Choose background color as gradient color.', 'beautyzone') ,
                        'default' => array(
                            'color' => '',
                            'alpha' => 1
                        ) ,
                        'options' => array(
                            'show_input' => true,
                            'show_initial' => true,
                            'show_alpha' => true,
                            'show_palette' => false,
                            'show_palette_only' => false,
                            'show_selection_palette' => true,
                            'max_palette_size' => 10,
                            'allow_empty' => true,
                            'clickout_fires_change' => false,
                            'choose_text' => 'Choose',
                            'cancel_text' => 'Cancel',
                            'show_buttons' => true,
                            'use_extended_classes' => true,
                            'palette' => null, // show default
                            'input_text' => 'Select Color'
                        ) ,
                        'hint' => array(
                            'title' => esc_html__('How it Works?', 'beautyzone') ,
                            'content' => esc_html__('1. Click on Select Color button content text here.', 'beautyzone') . '<br><br>' . esc_html__('2. Select the color as you want and click on Choose.', 'beautyzone') . '<br><br>' . esc_html__('3. On top / bottom of the panel click on Save Changes button.', 'beautyzone')
                        ) ,
                        'required' => array(
                            0 => 'body_boxed_bg_type',
                            1 => 'equals',
                            2 => 'bg_type_color'
                        )
                    ) ,
                    array(
                        'id' => 'boxed_layout_bg_image',
                        'type' => 'image_select',
                        'title' => esc_html__('Background Image', 'beautyzone') ,
                        'subtitle' => esc_html__('Select Background Image', 'beautyzone') ,
                        'desc' => esc_html__('Choose Background Image', 'beautyzone') ,
                        'options' => $this->theme_image_background_options,
                        'height' => '35',
                        'default' => 'bg_img_1',
                        'hint' => array(
                            'title' => esc_html__('Background Image', 'beautyzone') ,
                            'content' => esc_html__('Choose Background Image.', 'beautyzone')
                        ) ,
                        'required' => array(
                            0 => 'body_boxed_bg_type',
                            1 => 'equals',
                            2 => 'bg_type_image'
                        )
                    ) ,
                    array(
                        'id' => 'boxed_layout_custom_bg_image',
                        'type' => 'media',
                        'url' => true,
                        'height' => '35',
                        'title' => esc_html__('Custom Background Image', 'beautyzone') ,
                        'subtitle' => esc_html__('Select Custom Background Image.', 'beautyzone') ,
                        'desc' => esc_html__('Choose Custom Background Image.', 'beautyzone') ,
                        'default' => array(
                            'url' => get_template_directory_uri() . '/dz-inc/assets/images/bg-image/bg1.jpg'
                        ) ,
                        'hint' => array(
                            'title' => esc_html__('Custom Background Image', 'beautyzone') ,
                            'content' => esc_html__('Choose Custom Background Image if you want custom background but when you use custom background you do not use other image.', 'beautyzone')
                        ) ,
                        'required' => array(
                            0 => 'body_boxed_bg_type',
                            1 => 'equals',
                            2 => 'bg_type_image'
                        )
                    ) ,
                    array(
                        'id' => 'boxed_layout_bg_pattern',
                        'type' => 'image_select',
                        'title' => esc_html__('Background Pattern', 'beautyzone') ,
                        'subtitle' => esc_html__('Select Background Pattern.', 'beautyzone') ,
                        'desc' => esc_html__('Choose Background Pattern.', 'beautyzone') ,
                        'options' => $this->theme_pattern_background_options,
                        'default' => 'bg_pattern_1',
                        'height' => '35',
                        'hint' => array(
                            'title' => esc_html__('Background Pattern', 'beautyzone') ,
                            'content' => esc_html__('Choose background pattern if you want background pattern but when you use background pattern custom background you do not use other pattern.', 'beautyzone')
                        ) ,
                        'required' => array(
                            0 => 'body_boxed_bg_type',
                            1 => 'equals',
                            2 => 'bg_type_pattern'
                        )
                    ) ,
                    array(
                        'id' => 'boxed_layout_custom_bg_pattern',
                        'type' => 'media',
                        'url' => true,
                        'width' => '35',
                        'height' => '35',
                        'title' => esc_html__('Custom Background Pattern', 'beautyzone') ,
                        'subtitle' => esc_html__('Select Custom Background Pattern.', 'beautyzone') ,
                        'desc' => esc_html__('Choose Custom Background Pattern.', 'beautyzone') ,
                        'default' => array(
                            'url' => get_template_directory_uri() . '/dz-inc/assets/images/bg-pattern/bg1.jpg'
                        ) ,
                        'hint' => array(
                            'title' => esc_html__('Custom Background Pattern', 'beautyzone') ,
                            'content' => esc_html__('Choose Custom Background pattern if you want custom background but when you use custom background you do not use other pattern.', 'beautyzone')
                        ) ,
                        'required' => array(
                            0 => 'body_boxed_bg_type',
                            1 => 'equals',
                            2 => 'bg_type_pattern'
                        )
                    )
                )
            );

            $theme_fonts = array(
                'Font & Sizes' => array(
                    'id' => 'general',
                    'title' => 'General Fonts',
                    'heading' => 'General Settings',
                    'desc' => esc_html__('Choose fonts and font sizes for all pages', 'beautyzone')
                ) ,
            );

            foreach ($theme_fonts as $key => $font)
            {

                $font_id = $font['id'];
                $font_title = $font['title'];
                $font_heading = $font['heading'];
                $font_desc = $font['desc'];

                $this->sections[] = array(
                    'title' => $key,
                    'heading' => $font_heading,
                    'desc' => $font_desc,
                    'icon' => 'el-icon-text-width',
                    'subsection' => true,
                    'fields' => array(
                        array(
                            'id' => $font_id . '_font',
                            'type' => 'button_set',
                            'title' => $font_title,
                            'options' => array(
                                'Open-Sans' => esc_html__('Default', 'beautyzone') ,
                                'Google-Font' => esc_html__('Google Fonts', 'beautyzone') ,
                            ) ,
                            'default' => 'Open-Sans',
                        ) ,
                        array(
                            'id' => $font_id . '_font_body',
                            'type' => 'typography',
                            'title' => esc_html__('Body', 'beautyzone') ,
                            'subtitle' => esc_html__('This will be the default font for body tag of your website.', 'beautyzone') ,
                            'google' => true,
                            'font-backup' => true,
                            'all_styles' => true,
                            'text-align' => false,
                            'color' => true,
                            'output' => array(
                                'body'
                            ) ,
                            'units' => 'px',
                            'required' => array(
                                0 => $font_id . '_font',
                                1 => 'equals',
                                2 => 'Google-Font'
                            ) ,
                            'force_output' => true,

                        ) ,
                        array(
                            'id' => $font_id . '_font_h1',
                            'type' => 'typography',
                            'title' => esc_html__('H1', 'beautyzone') ,
                            'subtitle' => esc_html__('This will be the default font for all H1 tags of your website.', 'beautyzone') ,
                            'google' => true,
                            'font-backup' => true,
                            'all_styles' => true,
                            'text-align' => false,
                            'color' => true,
                            'output' => array(
                                'h1'
                            ) ,
                            'units' => 'px',
                            'required' => array(
                                0 => $font_id . '_font',
                                1 => 'equals',
                                2 => 'Google-Font'
                            ) ,
                            'force_output' => true
                        ) ,
                        array(
                            'id' => $font_id . '_font_h2',
                            'type' => 'typography',
                            'title' => esc_html__('H2', 'beautyzone') ,
                            'subtitle' => esc_html__('This will be the default font for all H2 tags of your website.', 'beautyzone') ,
                            'google' => true,
                            'font-backup' => true,
                            'all_styles' => true,
                            'text-align' => false,
                            'color' => true,
                            'output' => array(
                                'h2'
                            ) ,
                            'units' => 'px',
                            'required' => array(
                                0 => $font_id . '_font',
                                1 => 'equals',
                                2 => 'Google-Font'
                            ) ,
                            'force_output' => true
                        ) ,
                        array(
                            'id' => $font_id . '_font_h3',
                            'type' => 'typography',
                            'title' => esc_html__('H3', 'beautyzone') ,
                            'subtitle' => esc_html__('This will be the default font for all H3 tags of your website.', 'beautyzone') ,
                            'google' => true,
                            'font-backup' => true,
                            'all_styles' => true,
                            'text-align' => false,
                            'color' => true,
                            'output' => array(
                                'h3'
                            ) ,
                            'units' => 'px',
                            'required' => array(
                                0 => $font_id . '_font',
                                1 => 'equals',
                                2 => 'Google-Font'
                            ) ,
                            'force_output' => true
                        ) ,
                        array(
                            'id' => $font_id . '_font_h4',
                            'type' => 'typography',
                            'title' => esc_html__('H4', 'beautyzone') ,
                            'subtitle' => esc_html__('This will be the default font for all H4 tags of your website.', 'beautyzone') ,
                            'google' => true,
                            'font-backup' => true,
                            'all_styles' => true,
                            'text-align' => false,
                            'color' => true,
                            'output' => array(
                                'h4'
                            ) ,
                            'units' => 'px',
                            'required' => array(
                                0 => $font_id . '_font',
                                1 => 'equals',
                                2 => 'Google-Font'
                            ) ,
                            'force_output' => true
                        ) ,
                        array(
                            'id' => $font_id . '_font_h5',
                            'type' => 'typography',
                            'title' => esc_html__('H5', 'beautyzone') ,
                            'subtitle' => esc_html__('This will be the default font for all H5 tags of your website.', 'beautyzone') ,
                            'google' => true,
                            'font-backup' => true,
                            'all_styles' => true,
                            'text-align' => false,
                            'color' => true,
                            'output' => array(
                                'h5'
                            ) ,
                            'units' => 'px',
                            'required' => array(
                                0 => $font_id . '_font',
                                1 => 'equals',
                                2 => 'Google-Font'
                            ) ,
                            'force_output' => true
                        ) ,
                        array(
                            'id' => $font_id . '_font_h6',
                            'type' => 'typography',
                            'title' => esc_html__('H6', 'beautyzone') ,
                            'subtitle' => esc_html__('This will be the default font for all H6 tags of your website.', 'beautyzone') ,
                            'google' => true,
                            'font-backup' => true,
                            'all_styles' => true,
                            'text-align' => false,
                            'color' => true,
                            'output' => array(
                                'h6'
                            ) ,
                            'units' => 'px',
                            'required' => array(
                                0 => $font_id . '_font',
                                1 => 'equals',
                                2 => 'Google-Font'
                            ) ,
                            'force_output' => true
                        ) ,
                        array(
                            'id' => $font_id . '_font_p_tag',
                            'type' => 'typography',
                            'title' => esc_html__('P (Paragraph Text)', 'beautyzone') ,
                            'subtitle' => esc_html__('This will be the default font for all P tags of your website.', 'beautyzone') ,
                            'google' => true,
                            'font-backup' => true,
                            'all_styles' => true,
                            'text-align' => false,
                            'color' => true,
                            'output' => array(
                                'p'
                            ) ,
                            'units' => 'px',
                            'required' => array(
                                0 => $font_id . '_font',
                                1 => 'equals',
                                2 => 'Google-Font'
                            ) ,
                            'force_output' => true
                        )
                    )
                );
            }

            /*--------------------------------------------------------------
            # 11. Social Setting
            --------------------------------------------------------------*/
            $this->sections[] = array(
                'title' => esc_html__('Social Setting', 'beautyzone') ,
                'icon' => 'el el-twitter',
            );

            $socialLinkFiels[] = array(
                'id' => 'social_link_target',
                'type' => 'select',
                'title' => esc_html__('Choose Social Link Target', 'beautyzone') ,
                'options' => $this->link_target_options,
                'default' => '_blank'
            );

            foreach ($this->social_link_options as $social_link)
            {

                $sl_id = $social_link['id'];
                $sl_title = $social_link['title'];

                $socialLinkFiels[] = array(
                    'id' => 'social_' . $sl_id . '_url',
                    'type' => 'text',
                    'title' => $sl_title . esc_html__(' URL', 'beautyzone') ,
                    'subtitle' => esc_html__('Link to : ', 'beautyzone') . $sl_title,
                    'default' => '',
                );
            }

            $this->sections[] = array(
                'title' => esc_html__('Social Link', 'beautyzone') ,
                'icon' => 'el-icon-facebook',
                'subsection' => true,
                'fields' => $socialLinkFiels
            );

            $social_share_list = $social_share_default = array();
            $i = 1;
            foreach ($this->social_share_options as $social_link)
            {

                $social_share_list[$social_link['id']] = $social_link['title'];

                if ($i <= 3)
                {
                    $social_share_default[$social_link['id']] = true;
                }
                else
                {
                    $social_share_default[$social_link['id']] = false;
                }
                $i++;
            }

            $this->sections[] = array(
                'title' => esc_html__('Social Sharing', 'beautyzone') ,
                'icon' => 'el-icon-facebook',
                'subsection' => true,
                'fields' => array(
                    array(
                        'id' => 'social_shaing_on_post',
                        'type' => 'switch',
                        'title' => esc_html__('Enable Social Shaing On Post', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false
                    ) ,
                    array(
                        'id' => 'social_shaing_on_page',
                        'type' => 'switch',
                        'title' => esc_html__('Enable Social Shaing On Page', 'beautyzone') ,
                        'on' => esc_html__('Enabled', 'beautyzone') ,
                        'off' => esc_html__('Disabled', 'beautyzone') ,
                        'default' => false
                    ) ,
                    array(
                        'id' => 'share_sort_link',
                        'type' => 'sortable',
                        'title' => esc_html__('Social Sharing', 'beautyzone') ,
                        'subtitle' => esc_html__('Select active social share links and sort them with drag and drop.', 'beautyzone') ,
                        'mode' => 'checkbox',
                        'options' => $social_share_list,
                        // For checkbox mode
                        'default' => $social_share_default
                    )
                )
            );

            /*--------------------------------------------------------------
            # 12. Custom Script Setting
            --------------------------------------------------------------*/
            $this->sections[] = array(
                'title' => esc_html__('Custom Script', 'beautyzone') ,
                'icon' => 'el el-list-alt'
            );

            $this->sections[] = array(
                'title' => esc_html__('Custom Script', 'beautyzone') ,
                'icon' => 'el el-list-alt',
                'subsection' => true,
                'fields' => array(
                    array(
                        'id' => 'body_class',
                        'type' => 'text',
                        'title' => esc_html__('Body Class(s)', 'beautyzone') ,
                        'subtitle' => esc_html__('You can add one or more classes on theme body element. If you need more then one class, add them with a space between them.', 'beautyzone') ,
                        'desc' => esc_html__('Ex: body-class-1 body-class-2', 'beautyzone')
                    ) ,
                    array(
                        'id' => 'css_editor',
                        'type' => 'ace_editor',
                        'title' => esc_html__('CSS Code', 'beautyzone') ,
                        'subtitle' => esc_html__('Paste your CSS code here.', 'beautyzone') ,
                        'mode' => 'css',
                        'theme' => 'monokai'
                    ) ,
                    array(
                        'id' => 'js_editor',
                        'type' => 'ace_editor',
                        'title' => esc_html__('Javascript Code', 'beautyzone') ,
                        'subtitle' => esc_html__('Paste your JS code here.', 'beautyzone') ,
                        'mode' => 'javascript',
                        'theme' => 'chrome'
                    ) ,
                    array(
                        'id' => 'html_editor',
                        'type' => 'ace_editor',
                        'title' => esc_html__('HTML Code', 'beautyzone') ,
                        'subtitle' => esc_html__('Paste your HTML code here.', 'beautyzone') ,
                        'mode' => 'html',
                        'theme' => 'chrome'
                    )
                )
            );

            $this->sections[] = array(
                'title' => esc_html__('Analytic Code', 'beautyzone') ,
                'icon' => 'el-icon-edit',
                'subsection' => true,
                'fields' => array(

                    array(
                        'id' => 'site_header_code',
                        'type' => 'textarea',
                        'theme' => 'chrome',
                        'title' => esc_html__('Header Custom Codes', 'beautyzone') ,
                        'subtitle' => esc_html__('It will insert the code to wp_head hook.', 'beautyzone') ,
                    ) ,
                    array(
                        'id' => 'site_footer_code',
                        'type' => 'textarea',
                        'theme' => 'chrome',
                        'title' => esc_html__('Footer Custom Codes', 'beautyzone') ,
                        'subtitle' => esc_html__('It will insert the code to wp_footer hook.', 'beautyzone') ,
                    )
                )
            );

            /*--------------------------------------------------------------
            # 15. Advance Settings
            --------------------------------------------------------------*/
            $this->sections[] = array(
                'title' => esc_html__('Advance Options', 'beautyzone') ,
                'icon' => 'el el-cogs'
            );

            $advanceSettingSidebarFields[] = array(
                'id' => 'new_sidebar_input',
                'type' => 'multi_text',
                'title' => esc_html__('Sidebar Name', 'beautyzone') ,
                'subtitle' => esc_html__('Name your sidebar!', 'beautyzone') ,
                'desc' => esc_html__('Enter the text only. ', 'beautyzone') . '<a href="' . admin_url('widgets.php') . '" target="_blank">' . esc_html__('Click Here.', 'beautyzone') . '</a>' . esc_html__(' to check your sidebars', 'beautyzone') ,
                'hint' => array(
                    'title' => esc_html__('What to Do?', 'beautyzone') ,
                    'content' => esc_html__('1. Once you named your sidebar click on the Save Changes button @ the top of the panel.', 'beautyzone') . '<br><br>' . esc_html__('2. After save changes please just refresh the page, you will see the sidebar listed below.', 'beautyzone')
                ) ,
            );

            $sidebars_widgets = get_option('sidebars_widgets');

            if (!empty($sidebars_widgets))
            {
                $i = 1;
                foreach ($sidebars_widgets as $key => $value)
                {
                    $keyExt = substr($key, 3);
                    $keyRep1 = str_replace('-', ' ', $keyExt);
                    $keyRep2 = str_replace('-', '_', $keyExt);
                    $dzWidget = ucfirst($keyRep1);

                    if (strpos($key, 'dz-') === 0)
                    {
                        $advanceSettingSidebarFields[] = array(
                            'id' => 'avail_sidebar_' . $keyRep2 . '_' . $i,
                            'type' => 'info',
                            'style' => 'info',
                            'desc' => esc_html($dzWidget, 'beautyzone')
                        );
                    }
                    $i++;
                }
            }

            $this->sections[] = array(
                'title' => esc_html__('Create Sidebar', 'beautyzone') ,
                'icon' => 'el el-pencil',
                'desc' => esc_html__('DexignZone gives you the functionality to create your own Sidebars. Default there are three Sidebars as display below.', 'beautyzone') ,
                'subsection' => true,
                'fields' => $advanceSettingSidebarFields
            );
        }

        /**
         * Get default theme oiptions
         *
         * @param $key
         * @param $default
         * @return $value
         */
        function beautyzone_get_default_option($key, $default = '')
        {
            if (empty($key))
            {
                return '';
            }
            $options = get_option(beautyzone_get_opt_name() , array());
            $value = isset($options[$key]) ? $options[$key] : $default;

            return $value;
        }

    }

    global $beautyzonethemeoption;

    $beautyzonethemeoption = new Beautyzone_Redux_Framework_config();
}

