<?php	
	function beautyzone_dzbase()
	{
		return $GLOBALS['_dz_base'];
	}
	
	/** A function to fetch the categories from wordpress */
	function beautyzone_get_categories($arg = false)
	{	
		global $wp_taxonomies;		

		$beautyzone_categories_default_args = array(	
				'orderby'            => 'ID',
				'order'              => 'ASC',				
				'hide_empty'         => 1,				
				'hierarchical'       => true,				
		  );
		
		if( ! empty($arg['taxonomy']) && isset($wp_taxonomies[$arg['taxonomy']]) )
		{
			$beautyzone_categories_default_args['taxonomy'] = wp_kses_post($arg['taxonomy']);
		}
		
		$categories = get_categories($beautyzone_categories_default_args);		
		$cats = array();
		
		if( !is_wp_error( $categories ) ) {
			foreach($categories as $category)
			{
				$cats[$category->slug] = wp_kses($category->name,'string');				
			}
		}
		return $cats;
	}
	
	function beautyzone_get_the_breadcrumb()
	{	
		global $wp_query;
		$queried_object = get_queried_object();		
		$breadcrumb = '';
		$delimiter = ' ';
		$before = '<li>';
		$after = '</li>';
		if( ! is_home())
		{
			$breadcrumb .= '<li><a href="'.esc_url(home_url('/')).'"> '.esc_html__('Home', 'beautyzone').'</a></li>';
			
			/** If category or single post */
			if(is_category())
			{
				$cat_obj = $wp_query->get_queried_object();
				$this_category = get_category( $cat_obj->term_id );
		
				if ( $this_category->parent != 0 ) {
					$parent_category = get_category( $this_category->parent );
					$parent_string = get_category_parents($parent_category, TRUE, '@');			
					$parent_tree = explode('@',$parent_string);
					$parent_tree = array_filter($parent_tree);
					foreach($parent_tree as $cat_link)
					{
						$breadcrumb .= '<li>'. wp_kses_post($cat_link) .'</li>';	
					}	
				}				
				$single_cat_title = single_cat_title('', FALSE);				
				$breadcrumb .= '<li>'. wp_kses_post($single_cat_title).'</li>';
			}
			elseif(is_tax())
			{
				$term_link = get_term_link($queried_object);
				$term_name = $queried_object->name;				
				$breadcrumb .= '<li><a href="'.esc_url($term_link).'">'.wp_kses_post($term_name) .'</a></li>';
			}
			elseif(is_page()) /** If WP pages */
			{
				global $post;
				
				if($post->post_parent)
				{
					$anc = get_post_ancestors($post->ID);
					foreach($anc as $ancestor)
					{
						$perma_link = get_permalink($ancestor);
						$ancestor_title = get_the_title($ancestor);
						$post_title = get_the_title($post->ID);						
						$breadcrumb .= '<li><a href="'.esc_url($perma_link).'">'. wp_kses_post($ancestor_title) .'</a></li>';
					}
					$breadcrumb .= '<li>'. wp_kses($post_title,'string') .'</li>';
					
				}else{
					$post_title = get_the_title();
					$breadcrumb .= '<li>'. wp_kses($post_title,'string') .'</li>';
				}
			}
			elseif (is_singular())
			{
				if($category = wp_get_object_terms(get_the_ID(), 'category'))
				{
					if( !is_wp_error($category) )
					{
						$term_link = get_term_link(beautyzone_set($category, '0'));
						$name = beautyzone_set( beautyzone_set($category, '0'), 'name');
						$title = get_the_title();						
						$breadcrumb .= '<li><a href="'.esc_url($term_link).'">'. wp_kses_post($name) .'</a></li>';
						$breadcrumb .= '<li>'. wp_kses($title,'string') .'</li>';					
					} else{
						$title = get_the_title();
						$breadcrumb .= '<li>'. wp_kses($title,'string') .'</li>';
					}
				}else{
					$title = get_the_title();
					$breadcrumb .= '<li>'. wp_kses($title,'string') .'</li>';
				}
			}
			elseif(is_tag()){
				$term_link = get_term_link($queried_object);
				$title = single_tag_title('', FALSE);				
				$breadcrumb .= '<li><a href="'.esc_url($term_link).'">'. wp_kses($title,'string') .'</a></li>'; /**If tag template*/
			}
			elseif(is_day()){
				$time = get_the_time('F jS, Y');				
				$breadcrumb .= '<li><a href="#">'.esc_html__('Archive for ', 'beautyzone').wp_kses($time,'string').'</a></li>'; /** If daily Archives */
			}
			elseif(is_month()){
				$link = get_month_link(get_the_time('Y'), get_the_time('m'));
				$time = get_the_time('F, Y');				
				$breadcrumb .= '<li><a href="' .esc_url($link) .'">'.esc_html__('Archive for ', 'beautyzone'). wp_kses($time,'string') .'</a></li>'; /** If montly Archives */
			}
			elseif(is_year()){
				$link = get_year_link(get_the_time('Y'));
				$time = get_the_time('Y');	
				$breadcrumb .= '<li><a href="'.esc_url($link).'">'.esc_html__('Archive for ', 'beautyzone'). wp_kses($time,'string') .'</a></li>'; /** If year Archives */
			}
			elseif(is_author()){
				$link = get_author_posts_url( get_the_author_meta( "ID" ) );
				$author = get_the_author();
				$breadcrumb .= '<li><a href="'. esc_url( $link ) .'">'.esc_html__('Archive for ', 'beautyzone'). wp_kses($author,'string') .'</a></li>'; /** If author Archives */
			}
			elseif(is_search()){
				$search_query = get_search_query();
				$breadcrumb .= '<li>'.esc_html__('Search Results for ', 'beautyzone'). wp_kses_post($search_query) .'</li>'; /** if search template */
			}
			elseif(is_404()){
				$breadcrumb .= '<li>'.esc_html__('404 - Not Found', 'beautyzone').'</li>'; /** if search template */			
			}
			elseif(is_shop()){
				$term_name = beautyzone_get_opt('woocommerce_page_title');
				$breadcrumb .= '<li><a href="javascript:void(0)">'.wp_kses($term_name,'string') .'</a></li>'; /** if search template */			
			}
			else{
				$link = get_permalink();
				$title = get_the_title();
				if(!empty($title))
				{	
					$breadcrumb .= '<li><a href="'.esc_url($link).'">'. $title .'</a></li>'; /** Default value */
				}
			}
			
			/* To hide if only one li is available */
			if(substr_count($breadcrumb,'<li>') <= 1)
			{
				$breadcrumb = '';
			}
		}
		if(!empty($breadcrumb)){
			$breadcrumb = '<ul class="list-inline">'.$breadcrumb.'</ul>';
		}		
		return $breadcrumb;
	}

	function beautyzone_bunch_list_comments($comment, $args, $depth)
	{
		$GLOBALS['comment'] = $comment; 
		$email = beautyzone_set( $comment, 'comment_author_email' );		
		$avatar = get_avatar( $email, 130 );
		$comment_id = get_comment_ID();
		$author_link = get_comment_author($comment_id);
		$comment_date_link = get_month_link(get_the_date('Y'), get_the_date('m'));
		$comment_date = get_comment_date('F j, Y', $comment_id);				
		?>		
      <li <?php comment_class('comment');?> id="comment-<?php comment_ID(); ?>">
        <div class="comment-body" id="div-comment-<?php comment_ID(); ?>">
            <div class="comment-author vcard"> <?php echo wp_kses_post($avatar); ?>						
              <cite class="fn"><?php echo wp_kses_post($author_link); ?></cite> <span class="says"><?php esc_html_e('says:', 'beautyzone');?></span> 
            </div>
              <div class="comment-meta"> 
                <a href="<?php echo esc_url($comment_date_link); ?>"><?php echo wp_kses_post($comment_date); ?> <?php esc_html_e('at', 'beautyzone');?> <?php the_time('g:i a'); ?></a> 
              </div>
              <p><?php comment_text();?></p>
              <div class="reply"> 
                  <?php 
                    comment_reply_link(
                        array_merge(
                          $args,
                          array(
                          'depth' => $depth,
                          'max_depth' => $args['max_depth'],
                          'reply_text' => ''.esc_html__('Reply', 'beautyzone').'',
                          'add_below' => 'div-comment',
                        )
                      )
                    ); 
                  ?>
              </div>
          </div>
        </li>
        <!-- list END -->
  
  <!-- comment list END -->
 
		<?php	
	}
	/**
	 * returns the formatted form of the comments
	 *
	 * @param	array	$args		an array of arguments to be filtered
	 * @param	int		$post_id	if form is called within the loop then post_id is optional
	 *
	 * @return	string	Return the comment form
	 */
	function beautyzone_bunch_comment_form( $args = array(), $post_id = null, $review = false )
	{
		if ( null === $post_id )
		{$post_id = get_the_ID();}
		else
		{$id = $post_id;}
		$commenter = wp_get_current_commenter();
		$user = wp_get_current_user();
		$user_identity = $user->exists() ? $user->display_name : '';
		$args = wp_parse_args( $args );
		if ( ! isset( $args['format'] ) ){
			$args['format'] = current_theme_supports( 'html5', 'comment-form' ) ? 'html5' : 'xhtml';
		}
		$req      = get_option( 'require_name_email' );
		$aria_req = ( $req ? " aria-required='true'" : '' );
		$html5    = 'html5' === $args['format'];
		$fields   =  array(
			'author' => '<p class="comment-form-author"><label for="author">"'. esc_html('Name','beautyzone').'" <span class="required"></span></label><input id="name" placeholder="'. esc_attr__( 'Author', 'beautyzone' ).'"  name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" ' . $aria_req . ' /></p>',
			
       'email' => '<p class="comment-form-email"><label for="email">"'. esc_html('Email','beautyzone').'" <span class="required"></span></label><input id="email" placeholder="'. esc_attr__( 'Email', 'beautyzone' ).'"  name="email" type="text" value="' . esc_attr( $commenter['comment_author_email'] ) . '" ' . $aria_req . ' /></p>',
      
      
		);
		$required_text = sprintf( ' ' . esc_html__('Required fields are marked %s', 'beautyzone'), '<span class="required">*</span>' );
		/**
		 * Filter the default comment form fields.
		 *
		 * @since 3.0.0
		 *
		 * @param array $fields The default comment fields.
		 */
		$beautyzone_col = (is_user_logged_in()) ? 'col-md-12': ''; 
		$fields = apply_filters( 'comment_form_default_fields', $fields );
		$defaults = array(
			'fields'               => $fields,
			'comment_field'        => '<p class="comment-form-comment"><textarea id="comments" placeholder="'. esc_attr__( 'Type Comment Here', 'beautyzone' ).'" class="form-control4" name="comment" cols="45" rows="3" aria-required="true" required="required"></textarea></p>',
			'must_log_in'          => '<p class="col-md-12 col-sm-12">' . sprintf( wp_kses_post(__( 'You must be <a href="%s">logged in</a> to post a comment.', 'beautyzone' )), wp_login_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>',
			'logged_in_as'         => '<p class="col-md-12 col-sm-12">' . sprintf( wp_kses_post(__( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>', 'beautyzone' )), get_edit_user_link(), $user_identity, wp_logout_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>',
			'comment_notes_before' => '<div class="col-md-12 col-sm-12 m-b20">' . esc_html__( 'Your email address will not be published.', 'beautyzone' ) . ( $req ? $required_text : '' ) . '</div>',
			'comment_notes_after'  => '',
			'id_form'              => 'comments_form',
			'id_submit'            => 'submit',
			'title_reply'          => esc_html__( 'LEAVE A REPLY', 'beautyzone' ),
			'title_reply_to'       => esc_html__( 'Leave a Reply to %s', 'beautyzone' ),
			'cancel_reply_link'    => esc_html__( 'Cancel reply', 'beautyzone' ),
			'label_submit'         => esc_html__( 'Post Comment ', 'beautyzone' ),
			'format'               => 'xhtml',
		);
		/**
		 * Filter the comment form default arguments.
		 *
		 * Use 'comment_form_default_fields' to filter the comment fields.
		 *
		 * @since 3.0.0
		 *
		 * @param array $defaults The default comment form arguments.
		 */
		$args = wp_parse_args( $args, apply_filters( 'comment_form_defaults', $defaults ) );
			
			if ( comments_open( $post_id ) ) : ?>
				<?php
				/**
				 * Fires before the comment form.
				 *
				 * @since 3.0.0
				 */
				do_action( 'comment_form_before' );
				?>					
				 <div class="default-form comment-respond" id="respond">
					<div class="comment-reply-title">
						<span><?php esc_html( comment_form_title( $args['title_reply'], $args['title_reply_to'] )); ?></span>
					</div>
					<h3 class="comment-reply-title" id="reply-title">
						<small> <?php esc_url(cancel_comment_reply_link( $args['cancel_reply_link'] )); ?> </small>
					</h3>					
					<?php if ( get_option( 'comment_registration' ) && !is_user_logged_in() ) : ?>
						<?php echo wp_kses_post($args['must_log_in']); ?>
						<?php
						/**
						 * Fires after the HTML-formatted 'must log in after' message in the comment form.
						 *
						 * @since 3.0.0
						 */
						do_action( 'comment_form_must_log_in_after' );
						?>
					<?php else : ?>
						<form action="<?php echo site_url( '/wp-comments-post.php' ); ?>" method="post" id="<?php echo esc_attr( $args['id_form'] ); ?>" class="comment-form"<?php echo esc_attr($html5) ? ' novalidate' : ''; ?>>
							<div class="clearfix">
							<?php
							/**
							 * Fires at the top of the comment form, inside the <form> tag.
							 *
							 * @since 3.0.0
							 */
							do_action( 'comment_form_top' );
							?>
							<?php if ( is_user_logged_in() ) : ?>
								<?php
								/**
								 * Filter the 'logged in' message for the comment form for display.
								 *
								 * @since 3.0.0
								 *
								 * @param string $args['logged_in_as'] The logged-in-as HTML-formatted message.
								 * @param array  $commenter            An array containing the comment author's username, email, and URL.
								 * @param string $user_identity        If the commenter is a registered user, the display name, blank otherwise.
								 */
								echo apply_filters( 'comment_form_logged_in', $args['logged_in_as'], $commenter, $user_identity );
								?>
								<?php
								/**
								 * Fires after the is_user_logged_in() check in the comment form.
								 *
								 * @since 3.0.0
								 *
								 * @param array  $commenter     An array containing the comment author's username, email, and URL.
								 * @param string $user_identity If the commenter is a registered user, the display name, blank otherwise.
								 */
								do_action( 'comment_form_logged_in_after', $commenter, $user_identity );
								?>
							<?php else : ?>
								<?php echo wp_kses_post($args['comment_notes_before']); ?>
								<?php
								/**
								 * Fires before the comment fields in the comment form.
								 *
								 * @since 3.0.0
								 */
								do_action( 'comment_form_before_fields' );
								foreach ( (array) $args['fields'] as $name => $field ) {
									/**
									 * Filter a comment form field for display.
									 *
									 * The dynamic portion of the filter hook, $name, refers to the name
									 * of the comment form field. Such as 'author', 'email', or 'url'.
									 *
									 * @since 3.0.0
									 *
									 * @param string $field The HTML-formatted output of the comment form field.
									 */
									echo apply_filters( "comment_form_field_{$name}", $field ) . "\n";
								}
								/**
								 * Fires after the comment fields in the comment form.
								 *
								 * @since 3.0.0
								 */
								do_action( 'comment_form_after_fields' );
								?>
							<?php endif; ?>
							<?php
							/**
							 * Filter the content of the comment textarea field for display.
							 *
							 * @since 3.0.0
							 *
							 * @param string $args['comment_field'] The content of the comment textarea field.
							 */
							echo apply_filters( 'comment_form_field_comment', $args['comment_field'] );
							?>
							<?php echo wp_kses_post($args['comment_notes_after']); ?>
								<p class="col-md-12 col-sm-12 col-xs-12 form-submit">
									<input id="<?php echo esc_attr( $args['id_submit'] ); ?>" type="submit" class="submit btn radius-no secondry">
								</p>
							  <?php comment_id_fields( $post_id ); ?>
							<?php
							/**
							 * Fires at the bottom of the comment form, inside the closing </form> tag.
							 *
							 * @since 1.5.2
							 *
							 * @param int $post_id The post ID.
							 */
							do_action( 'comment_form', $post_id );
							?>
							</div>
						</form>
					<?php endif; ?>
				</div><!-- #respond -->
				<?php
				/**
				 * Fires after the comment form.
				 *
				 * @since 3.0.0
				 */
				do_action( 'comment_form_after' );
			else :
				/**
				 * Fires after the comment form if comments are closed.
				 *
				 * @since 3.0.0
				 */
				do_action( 'comment_form_comments_closed' );
			endif;
	}

	function beautyzone_the_pagination($query = array(), $args = array(), $echo = 1)
	{
		global $wp_query;
		
		
		if(!empty($query))
		{ 
			$temp_query = $wp_query;
			$wp_query   = NULL;
			$wp_query   = $query;
		}
		
		$paged = get_query_var('paged');
		
		$default =  array(
			'base' => str_replace( 99999, '%#%', esc_url( get_pagenum_link( 99999 ) ) ), 
			'format' => '?paged=%#%', 
			'current' => max( 1, $paged ),
			'total' => $wp_query->max_num_pages, 
			'show_all' => true, 
			'next_text' => '<i class="ti-arrow-right"></i>', 
			'prev_text' => '<i class="ti-arrow-left"></i>', 
			'type'=>'list',
			'add_args' => false,			
		);

		$args = wp_parse_args($args, $default);	

		$pagination = str_replace("<ul class='page-numbers'", '<ul class="pagination"', paginate_links($args) );		
	$pagination = '<div class="pagination-bx clearfix text-center">
					<div class="pagination">'.$pagination.'</div>
				</div>';		
	
		echo wp_kses_post($pagination);
	}			
	
	function beautyzone_trim( $text, $len, $more = null )
	{	
		$text = strip_shortcodes( $text );	
		$text = apply_filters( 'the_content', $text );
		$text = str_replace(']]>', ']]&gt;', $text);	
		$excerpt_length = apply_filters( 'excerpt_length', $len );	
		$excerpt_more = apply_filters( 'excerpt_more', ' ' . '[&hellip;]' );	
		$excerpt_more = ( $more ) ? $more : '';	
		$text = wp_trim_words( $text, $excerpt_length, $excerpt_more );
		
		return $text;	
	}
	
	
	
	function beautyzone_get_social_icons($show_position = 'all',$default_class='site-button-link hover')
	{	
		$options = beautyzone_dzbase()->option();
		
		$output = '';			
		$target = $options['social_link_target'];
		$social_link_options = beautyzone_social_link_options();
		
		if($show_position == 'header')
		{
			
			/*reCheck function and rebuild it for fast performance */
			
			global $beautyzone_option;
			$header_social_links = beautyzone_set($beautyzone_option,'header_social_links');
			
			
			$header_show_links = []; 
			$updated_social_links = array();
			foreach($header_social_links as $key => $value){
				
				if($value == 1){
					$header_show_links[] = $key; 
				}
			
			}
			foreach($social_link_options as $social_key => $social_link){
				if(in_array($social_link['id'], $header_show_links)){
					$updated_social_links[$social_key] = $social_link;
				}
			}
			
			$social_link_options = $updated_social_links;
			
		}
		
		foreach ($social_link_options as $social_link) {
			
				
				$id = $social_link['id'];
				$sl_id = 'social_' . $id . '_url';
				
				$sl_title = $social_link['title'];

				if(!empty($options[$sl_id]))
				{
					$output .= '<li><a target="'. esc_attr($target).'" href="'.esc_url( $options[$sl_id] ).'"  class="'.esc_attr($id).' '.esc_attr($default_class).'"><i class="fa fa-'.esc_attr($id).'"></i></a></li>'."\n";	
				}
		}
		return $output;
	}

	function beautyzone_short_description($excerpt = '', $content = '', $limit = 250, $more = null){
		
		if(empty($excerpt) && empty($content)){return false;}
		
		$short_description = '';
		
		if(!empty($excerpt)){
			$short_description = wp_kses_post($excerpt);
		}
		else
		{	
			if ( has_blocks( $content ) ) {	
				$blocks = parse_blocks( $content );
				
				foreach($blocks as $k ){
					if ( $k['blockName'] === 'core/paragraph' ) {
						if(!empty($k['innerHTML'])){
							$short_description = wp_kses_post($k['innerHTML']);
							break;
						}
					}
				}
			}
			else{
				$short_description = $content;
			}
		}	
		$short_description = beautyzone_trim($short_description, $limit, $more);
		
		return $short_description;
	}
	/*
		Ajax - Home pages listing
	*/
	function beautyzone_load_posts_by_ajax_callback() {	
		check_ajax_referer('ajax_security_key', 'security');   
		global $beautyzone_query_result;
		
		$post_type = !empty($_POST['post_type'])? $_POST['post_type'] : 'post';
		
		$query_args = array(	
			'post_type' 		=> $post_type,
			'post_status' 		=> 'publish',
			'posts_per_page'   	=> $_POST['posts_per_page'],	
			'paged' 			=> $_POST['page'],	
			'order' 			=> $_POST['post_order'],
			'ignore_sticky_posts' => true,
		);		
		
		if($_POST['posts_image_preference'] == 'image_post_only')
		{
			$query_args['meta_query'] = array(
				array(
				 'key' => '_thumbnail_id',
				 'compare' => 'EXISTS'
				),
			);
		}
		elseif($_POST['posts_image_preference'] == 'text_post_only')
		{
			$query_args['meta_query'] = array(
				array(
				 'key' => '_thumbnail_id',
				 'compare' => 'Not EXISTS'
				),
			);
		}			
		
		if($_POST['posts_in_categories']) 
		{ 
			
			if(!empty($_POST['post_type']) && $_POST['post_type'] != 'post')
			{
				/* This is category searching only for custom post type */
				$cat_arr = explode(',',$_POST['posts_in_categories']);
				
				$taxonomy = get_object_taxonomies($_POST['post_type']);
				
				$taxonomy = !empty($taxonomy[0])?$taxonomy[0]:'category';
				
				$query_args['tax_query'][] = array(
											'taxonomy' => $taxonomy,
											'field' => 'id',
											'terms' => $cat_arr,
											'operator' => 'IN'
											);
			}else{
				$query_args['category_name'] = $_POST['posts_in_categories'];
				
			}								
		}
		
		if($_POST['post_by_label'] == 'sticky_only')
		{
			$query_args['post__in']	= get_option( 'sticky_posts' );	
			$query_args['ignore_sticky_posts']	= true;
		}
		
		if($_POST['only_featured_post'] == 'yes') { 		
			$query_args['meta_key'] = 'featured_post';		
			$query_args['meta_value'] = 1;				
			$query_args['meta_compare'] = 'LIKE';		
		}
		
		if($_POST['post_order_by'] == 'views_count'){
			$query_args['meta_key']	= '_views_count';
		}
		else{
			$query_args['orderby']	= $_POST['post_order_by'];
		}
		
		$query = new WP_Query( $query_args );			
		$beautyzone_query_result['posts'] = $query->posts;		
		$beautyzone_query_result['posts_per_page'] = $_POST['posts_per_page'];
		$beautyzone_query_result['current_page'] = $_POST['page'];
		$beautyzone_query_result['side_bar'] = $_POST['side_bar'];
		$beautyzone_query_result['title_text_limit'] = $_POST['title_text_limit'];

		switch ($_POST['blog_view']) {
			case "post_listing_1": 			
				get_template_part('dz-inc/vc/ajax/post_listing_1_ajax');
				break;
			case "post_listing_2": 			
				get_template_part('dz-inc/vc/ajax/post_listing_2_ajax');
				break;
			case "post_listing_3": 			
				get_template_part('dz-inc/vc/ajax/post_listing_3_ajax');
				break;
			case "post_listing_4": 			
				get_template_part('dz-inc/vc/ajax/post_listing_4_ajax');
				break;
			case "post_listing_5": 			
				get_template_part('dz-inc/vc/ajax/post_listing_5_ajax');
				break;
			case "post_listing_6": 			
				get_template_part('dz-inc/vc/ajax/post_listing_6_ajax');
				break;
		}	
		
		unset($GLOBALS['beautyzone_query_result']);	
		wp_reset_postdata();
		wp_die();
	}
	add_action('wp_ajax_load_posts_by_ajax', 'beautyzone_load_posts_by_ajax_callback');
	add_action('wp_ajax_nopriv_load_posts_by_ajax', 'beautyzone_load_posts_by_ajax_callback');
	
	/*
		AJAX - Mega menu
	*/
	function beautyzone_load_mega_menu_posts_ajax_callback() {
		check_ajax_referer('ajax_security_key', 'security');   
		global $beautyzone_query_result;		
		$query_args = array(	
			'post_type' 		=> 'post',
			'post_status' 		=> 'publish',
			'posts_per_page'   	=> $_POST['posts_per_page'],	
			'paged' 			=> $_POST['page'],	
			'ignore_sticky_posts' => true,
			'orderby' 			=> 'date',
			'order' 			=> 'DESC',			
		);
		
		if($_POST['posts_in_categories']) { 
			$query_args['cat'] = $_POST['posts_in_categories'];		
		}
		
		if($_POST['mega_menu_images_only'] == 'yes')
		{		
			$query_args['meta_query'] = array(
				array(
				 'key' => '_thumbnail_id',
				 'compare' => 'EXISTS'
				),
			);
		}
		
		$query = new WP_Query( $query_args ); 		
		set_query_var( 'query', $query );	
		get_template_part('dz-inc/ajax/mega_menu_ajax');		
		wp_reset_postdata();
		wp_die();
	}
	add_action('wp_ajax_load_mega_menu_posts_by_ajax', 'beautyzone_load_mega_menu_posts_ajax_callback');
	add_action('wp_ajax_nopriv_load_mega_menu_posts_by_ajax', 'beautyzone_load_mega_menu_posts_ajax_callback');

	/*
		AJAX - Categories, Search, Tags, Archive, Author
	*/
	function beautyzone_load_common_page_posts_ajax_callback() {
		check_ajax_referer('ajax_security_key', 'security'); 		
		$beautyzone_query_result = array();
		$query_args = array(	
			'post_type' 		=> 'post',
			'post_status' 		=> 'publish',
			'posts_per_page'   	=> $_POST['posts_per_page'],	
			'paged' 			=> $_POST['page'],
			'ignore_sticky_posts' => true,			
		);
    
		$orderby = isset($_POST['orderby'])?$_POST['orderby']:'date';
		$order   = isset($_POST['order'])?$_POST['order']:'DESC';
			
		if($orderby == '_views_count')
		{
		  $query_args['meta_key']	= '_views_count';
		  $order = 'DESC';
		}
    
		$query_args['orderby']	= $orderby;
		$query_args['order'] = $order;
    
		$template = '';
		
		if( $_POST['page_view'] == 'author' ) { 		
			$query_args['author'] = $_POST['object_data'];				
			$template = 'author_ajax';
		}		
		if($_POST['page_view'] == 'category') { 
			$query_args['cat'] = $_POST['object_data'];	
			$template = 'category_ajax';	
		}		
		if($_POST['page_view'] == 'search') { 
			$query_args['s'] = $_POST['object_data'];	
			$template = 'search_ajax';
		}		
		if($_POST['page_view'] == 'tag') { 
			$query_args['tag_id'] = $_POST['object_data'];	
			$template = 'tag_ajax';
		}		
		if($_POST['page_view'] == 'archive') { 
			$object_data = explode('/', $_POST['object_data']);
			$query_args['year'] = $object_data[0];	
			
			if( isset($object_data[1]) && !empty($object_data[1]) ){
				$query_args['monthnum'] = $object_data[1];
			}
			
			$template = 'archive_ajax';
		}	
		
		$query = new WP_Query( $query_args );		
		set_query_var( 'beautyzone_query_result', $query );		
		get_template_part('dz-inc/ajax/'. $template);
		wp_reset_postdata();
		wp_die();
	}
	add_action('wp_ajax_load_common_page_posts_ajax', 'beautyzone_load_common_page_posts_ajax_callback');
	add_action('wp_ajax_nopriv_load_common_page_posts_ajax', 'beautyzone_load_common_page_posts_ajax_callback');

	
	/*
		AJAX - index page :-
	*/
	function beautyzone_load_latest_posts_ajax_callback() {
		check_ajax_referer('ajax_security_key', 'security');		
		$beautyzone_query_result = array();
		$query_args = array(	
			'post_type' 		=> 'post',
			'post_status' 		=> 'publish',
			'posts_per_page'   	=> $_POST['posts_per_page'],	
			'paged' 			=> $_POST['page'],	
			'orderby' 			=> 'post_date',
			'ignore_sticky_posts' => true,
			'order' 			=> 'DESC',
		);			
		
		$query = new WP_Query( $query_args );			
		set_query_var( 'beautyzone_query_result', $query );		
		get_template_part('dz-inc/ajax/index_ajax');
		wp_reset_postdata();
		wp_die();
	}
	add_action('wp_ajax_load_latest_posts_ajax', 'beautyzone_load_latest_posts_ajax_callback');
	add_action('wp_ajax_nopriv_load_latest_posts_ajax', 'beautyzone_load_latest_posts_ajax_callback');
	
	/* Run Code */
	if( !function_exists( 'beautyzone_shortcode' ) ) {
		function beautyzone_shortcode($output) {
			return $output;
		}
	}
	/* Run Code END */
	
if(!function_exists('beautyzone_share_us'))
{

	function beautyzone_share_us($post_id = '', $post_title = '', $share_on = '')
	{
		$social_shaing = beautyzone_get_opt('social_shaing_on_post');
		
		/* Control Post Sharing */
			if(!$social_shaing)
			{ return false; }
		/* Control Post Sharing END */
		
		$response 			= '';
		$options			= get_option('beautyzone_theme_options');
		$share_sort_links	= beautyzone_set($options, 'share_sort_link');
		$social_share_link	= array(
			'facebook'=>'http://www.facebook.com/sharer.php?u='.esc_url(get_permalink($post_id)),
			'twitter'=>'https://twitter.com/share?url='.esc_url(get_permalink($post_id)).'&text='.esc_attr($post_title),
			'google-plus'=>'https://plus.google.com/share?url='.esc_url(get_permalink($post_id)),
			'linkedin'=>'http://www.linkedin.com/shareArticle?url='.esc_url(get_permalink($post_id)).'&title='.esc_attr($post_title),
			'pinterest'=>'http://pinterest.com/pin/create/button/?url='.esc_url(get_permalink($post_id)).'&media='.esc_url(get_the_post_thumbnail_url($post_id)).'&description='.esc_attr($post_title),
			'reddit'=>'http://reddit.com/submit?url='.esc_url(get_permalink($post_id)).'&title='.esc_attr($post_title),
			'tumblr'=>'http://www.tumblr.com/share/link?url='.esc_url(get_permalink($post_id)).'&name='.esc_attr($post_title),
			'digg'=>'http://digg.com/submit?url='.esc_url(get_permalink($post_id)).'&title='.esc_attr($post_title),
		);
		
		if($share_on == 'PostSingle')
		{
			$response = '<ul>
              <li><h5 class="m-a0">'.esc_html__('Share Post ', 'beautyzone').': </h5></li>';
		}else{
			$response = '<ul>
      <li><h5 class="m-a0">'.esc_html__('Share Post ', 'beautyzone').': </h5></li>';
			
		}
		
		
		if(!empty($share_sort_links))
		{
			foreach($share_sort_links as $icon_key => $icon_value)
			{
				$anchor_class = 'site-button button-sm';
				if($share_on == 'PostSingle')
				{ 
					$anchor_class = 'site-button button-sm '.$icon_key; 
				}else{
					$anchor_class = 'site-button button-sm'; 
				}
			
				if($icon_value){
					$response .= '<li><a class="'.$anchor_class.' '.$icon_key.'" href="'.esc_url($social_share_link[$icon_key]).'" target="_blank" ><i class="fa fa-'.$icon_key.'"></i> ' .$icon_key. ' </a></li> ';	
				}
			}
		}
		
		if($share_on == 'PostSingle')
		{
			$response .= '</ul>';
		}else{
			$response .= '</ul>';	
		}
		
		
		
		return $response;
	}
}

if(!function_exists('beautyzone_author_social_link'))
{

	function beautyzone_author_social_arr()
	{
		$author_social_arr = array(
								'url'=>array('icon'=>'fa fa-globe','text'=>'Globe'),
								'facebook'=>array('icon'=>'fa fa-facebook','text'=>'Facebook'),
								'twitter'=>array('icon'=>'fa fa-twitter','text'=>'Twitter'),
								'linkedin'=>array('icon'=>'fa fa-linkedin','text'=>'Linkedin'),
								'dribbble'=>array('icon'=>'fa fa-dribbble','text'=>'Dribble'),
								'github'=>array('icon'=>'fa fa-github','text'=>'Github'),
								'flickr'=>array('icon'=>'fa fa-flickr','text'=>'Flickr'),
								'google-plus'=>array('icon'=>'fa fa-google-plus','text'=>'Google Plus'),
								'youtube'=>array('icon'=>'fa fa-youtube','text'=>'Youtube'),
								);
								
		return $author_social_arr;
	}
}


function beautyzone_get_website_logo_old($logo_key) 
{

	$output = "";
	$logo 		= beautyzone_get_opt($logo_key);
	
	if(!empty($logo['url']))
	{
		$logo = $logo['url'];
	}else{
		$logo = ($logo_key == 'site_logo')?BEAUTYZONE_DEFAULT_LOGO:BEAUTYZONE_DEFAULT_WHITE_LOGO;
	}
	
	$logo_type	=	beautyzone_get_opt('logo_type','image_logo');
	$logo_title = 	beautyzone_get_opt('logo_title',esc_html__('Logo','beautyzone'));
	$logo_alt 	= 	beautyzone_get_opt('logo_alt',esc_html__('Logo','beautyzone'));
	
	if($logo_type == 'text_logo') 
	{
		$logo_text 	= 	beautyzone_get_opt('logo_text',esc_html__('BeautyZone','beautyzone'));
		$logo_tag 	= 	beautyzone_get_opt('tag_line',esc_html__('BeautyZone','beautyzone'));
		
		$output .= '<div class="text-logo">';
		if(!empty($logo_text)) {
			$output .= '<h1 class="site-title">';
			$output .= '<a href="'.esc_url( home_url( '/' ) ).'" title="'.esc_attr($logo_title).'">';
			$output .= esc_html($logo_text);
			$output .= '</a>';
			$output .= '</h1>';
		}
		if(!empty($logo_tag)) {
			$output .= '<p class="site-description">';
			$output .= esc_html($logo_tag);
			$output .= '</p>';
		}
		$output .= '</div>';
	}
	else {
		$output .= '<a href="'.esc_url( home_url( '/' ) ).'" title="'.esc_attr($logo_title).'">';
		$output .= '<img src="'.esc_url($logo).'" alt="'.esc_attr($logo_alt).'"/>';
		$output .= '</a>';
	}

	echo wp_kses_post($output);
}


function beautyzone_get_website_logo($logo_key = 'header_logo') 
{
	global $beautyzone_option;
	extract($beautyzone_option);
	$page_logo_setting = $output = '';
	if(is_page()){
		$page_logo_setting	= beautyzone_dzbase()->get_meta('page_logo_setting'); 
		$page_logo_setting	= !empty($page_logo_setting)?$page_logo_setting:'theme_default';
	}
	
	
	
	
	// Logo Class 
	$class = '';
	if($logo_key == 'site_other_logo'){
		$class = 'light-logo';
	}else if($logo_key == 'site_logo'){
		$class = 'dark-logo';
	}
	
	$class = !empty($class)?'class="'.$class.'"':'';
	
	// Logo URL
	$logo_url = $$logo_key;
	
	/* Demo Code: remove_package */
	if(is_page('home-3') || is_page('home-3-one-page')){
		if($logo_key == 'site_other_logo'){
			$logo_url = get_template_directory_uri() . '/assets/images/logo.png';
		}else if($logo_key == 'site_logo'){
			$logo_url = get_template_directory_uri() . '/assets/images/logo-3.png';
		}
	}else if(is_page('home-4') || is_page('home-4-one-page') ){
		if($logo_key == 'site_other_logo'){
			$logo_url = get_template_directory_uri() . '/assets/images/logo.png';
		}else if($logo_key == 'site_logo'){
			$logo_url = get_template_directory_uri() . '/assets/images/logo-4.png';
		}
	}else if(is_page('home-5') || is_page('home-5-one-page') ){
		if($logo_key == 'site_other_logo'){
			$logo_url = get_template_directory_uri() . '/assets/images/logo-3.png';
		}else if($logo_key == 'site_logo'){
			$logo_url = get_template_directory_uri() . '/assets/images/logo-white-3.png';
		}
	}else if(is_page('home-2') || is_page('home-2-one-page')  || is_page('home-1-one-page')){
		if($logo_key == 'site_other_logo'){
			$logo_url = get_template_directory_uri() . '/assets/images/logo.png';
		}else if($logo_key == 'site_logo'){
			$logo_url = get_template_directory_uri() . '/assets/images/logo-2.png';
		}
	}else{
		if($logo_key == 'site_other_logo'){
			$logo_url = get_template_directory_uri() . '/assets/images/logo.png';
		}else if($logo_key == 'site_logo'){
			$logo_url = get_template_directory_uri() . '/assets/images/logo-2.png';
		}
	}
	
	
	if(is_page('header-3') || is_page('header-4')){		
		$logo_url = get_template_directory_uri() . '/assets/images/logo-white-2.png';
	}
	
	/* Demo Code: remove_package END */
	if($logo_type == 'text_logo') 
	{
		$logo_text 	= 	beautyzone_get_opt('logo_text',esc_html__('BeautyZone','beautyzone'));
		$logo_tag 	= 	beautyzone_get_opt('tag_line',esc_html__('BeautyZone','beautyzone'));
		
		$output .= '<div class="text-logo">';
		if(!empty($logo_text)) {
			$output .= '<h1 class="site-title">';
			$output .= '<a href="'.esc_url( home_url( '/' ) ).'" title="'.esc_attr($logo_title).'">';
			$output .= esc_html($logo_text);
			$output .= '</a>';
			$output .= '</h1>';
		}
		if(!empty($logo_tag)) {
			$output .= '<p class="site-description">';
			$output .= esc_html($logo_tag);
			$output .= '</p>';
		}
		$output .= '</div>';
	}
	else {
		$output .= '<a href="'.esc_url( home_url( '/' ) ).'" '.$class.' title="'.esc_attr($logo_title).'">';
		$output .= '<img src="'.esc_url($logo_url).'" alt="'.esc_attr($logo_alt).'"/>';
		$output .= '</a>';
	}

	echo wp_kses_post($output);
}
add_action('beautyzone_get_logo', 'beautyzone_get_website_logo',2);


function beautyzone_get_super_user_data($userMeta='') {
	
	$admin_email = get_option('admin_email');
	$adminDetail = get_user_by('email',$admin_email);
	if(isset($adminDetail->data->ID)){
		$userMetaValue = get_the_author_meta($userMeta,$adminDetail->data->ID);
		return $userMetaValue;
	}
}


function beautyzone_get_super_user_displayname($userMeta="") {
	
	$admin_email = get_option('admin_email');
	$adminDetail = get_user_by('email',$admin_email);

	return $adminDetail->data->display_name;
}

function beautyzone_get_super_user_description() {
	
	$admin_email = get_option('admin_email');
	$adminDetail = get_user_by('email',$admin_email);
	$meta = get_user_meta($adminDetail->data->ID);
	$description = !empty($meta['description'][0])?$meta['description'][0]:''; 
	return $description;
}

function beautyzone_get_domain($url)
{
    $pieces = parse_url($url);
    $domain = isset($pieces['host']) ? $pieces['host'] : '';
    if(preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)){
        return $regs['domain'];
    }
    return false;
}
function beautyzone_get_youtube_video_id($video_url){
	$res = 0;
	if(preg_match("/(youtube.com|youtu.be)\/(watch)?(\?v=)?(\S+)?/", $video_url, $res)){
		return $res[4];
	}else{
		return 0;
	}
}

/* Show Only One Category : only for demo */
function beautyzone_get_the_category_list($cat_list,$b)
{
	$category = array();
	$category[] = $cat_list[0]; 
	return $category;
}


/* Show Only One Category : only for demo END */

/* Hide Some Category From Widget : only for demo */
function beautyzone_exclude_widget_categories($args)
{
	$hide_selected_cat 	= beautyzone_get_opt('hide_selected_cat');
    if(!empty($hide_selected_cat))
	{
			$hide_selected_cat = implode(',',$hide_selected_cat);
			$args['exclude'] = $hide_selected_cat;
			return $args;
	}
}

/* Hide Some Category From Widget : only for demo END */

/* Show Feature Image In Post Listing */
function beautyzone_custom_columns( $columns ) 
{
    $columns = array(
        'cb' => '<input type="checkbox" />',
        'featured_image' => 'Image',
        'title' => 'Title',
        'comments' => '<span class="vers"><div title="Comments" class="comment-grey-bubble"></div></span>',
        'author' => 'Author',
        'categories' => 'Cateogies',
        'tags' => 'Tags',
		'date' => 'Date',
     );
    return $columns;
}


function beautyzone_custom_columns_data( $column, $post_id )
{
    switch ( $column ) {
    case 'featured_image':
        the_post_thumbnail( 'thumbnail' );
        break;
    }
}
/* Show Feature Image In Post Listing END */


function beautyzone_ext_options()
{
	$show_only_one_cat 			= beautyzone_get_opt('show_only_one_cat');
	$hide_cat_from_widget 		= beautyzone_get_opt('hide_cat_from_widget');
	$show_image_on_post_list 	= beautyzone_get_opt('show_image_on_post_list');
	
	
	if($show_only_one_cat){
		add_action( 'the_category_list' , 'beautyzone_get_the_category_list', 10, 2 );
	}
	
	if($hide_cat_from_widget){
		add_filter('widget_categories_args','beautyzone_exclude_widget_categories');
	}
	if($show_image_on_post_list)
	{
		add_filter('manage_post_posts_columns' , 'beautyzone_custom_columns');
		add_action( 'manage_post_posts_custom_column' , 'beautyzone_custom_columns_data', 10, 2 );
	}
}

add_action( 'init' , 'beautyzone_ext_options');


function beautyzone_is_theme_sidebar_active(){
	return beautyzone_get_opt('show_sidebar',true);
}

function beautyzone_show_post_view_count_view($views)
{
	$post_view_on = beautyzone_get_opt('post_view_on',false);
	$view_html = '';
	if($post_view_on)
	{
		$post_start_view = beautyzone_get_opt('post_start_view',0);
		$views	= $views + $post_start_view;
		
		$view_html = '<li class="post-view"><a href="javascript:void(0);"><i class="ti-eye"></i><span>'.wp_kses($views,'string').'</span></a></li>';
	}
	
	return $view_html;
}

function beautyzone_get_banner()
{
  
	global $beautyzone_option;
	
	$header_style = isset($beautyzone_option['header_style'])?$beautyzone_option['header_style']:'header_1';
	
	$theme_options = beautyzone_get_theme_option();


	$template_name = 'page_general';
	if(is_page())
	{ 
		$template_name 			= 'page_general';
		$page_banner_setting	= beautyzone_dzbase()->get_meta('page_banner_setting'); 
	}
	
	$page_banner_setting	= !empty($page_banner_setting)?$page_banner_setting:'theme_default';
	$title_prefix			= '';
	
	if(is_author()){
		$template_name	= 'author_page';
		$title_prefix	= esc_html__('Author :', 'beautyzone');
	}else if(is_search()){
		$template_name	= 'search_page';
		$title_prefix	= esc_html__('Search :', 'beautyzone');
	}else if(is_category()){
		$template_name	= 'category_page';
		$title_prefix	= esc_html__('Category :', 'beautyzone');
	}else if( beautyzone_is_woocommerce_active() && ((function_exists('is_shop') && is_shop()) || (function_exists('is_product_category') && is_product_category()))){
		$template_name	= 'woocommerce_page';
		$title_prefix	= esc_html__('Product :', 'beautyzone');
	}else if(is_tag()){
		$template_name	= 'tag_page';
		$title_prefix	= esc_html__('Tag :', 'beautyzone');
	}else if(is_archive()){
		$template_name	= 'archive_page';
		$title_prefix	= esc_html__('Archive :', 'beautyzone');
	}

	$page_banner_title = $page_banner_sub_title = '';
	
if($page_banner_setting == 'custom')
	{
		$show_banner	= beautyzone_dzbase()->get_meta('page_banner_on');
		$banner_type	= beautyzone_dzbase()->get_meta('page_banner_type');
		$banner_height	= beautyzone_dzbase()->get_meta('page_banner_height');
		$custom_height	= beautyzone_dzbase()->get_meta('page_banner_custom_height');
		$banner_image	= beautyzone_dzbase()->get_meta('page_banner');
		$banner_hide			= beautyzone_dzbase()->get_meta('page_banner_hide');
		$page_banner_title		= beautyzone_dzbase()->get_meta('page_banner_title');
		$page_banner_sub_title	= beautyzone_dzbase()->get_meta('page_banner_sub_title');
		
		$show_breadcrumb = beautyzone_dzbase()->get_meta('page_breadcrumb');
		$banner_image	= beautyzone_set($banner_image,'url');
	}
	else
	{
		$title_prefix   = beautyzone_set($theme_options,$template_name.'_title',$title_prefix);
		$show_banner   	= beautyzone_set($theme_options,$template_name.'_banner_on',true);
		$banner_type   	= beautyzone_set($theme_options,$template_name.'_banner_type','image');
		$banner_height  = beautyzone_set($theme_options,$template_name.'_banner_height','page_banner_small');
		$custom_height  = beautyzone_set($theme_options,$template_name.'_banner_custom_height','100');	
		$banner_image   = beautyzone_set($theme_options,$template_name.'_banner');
		$banner_image   = beautyzone_set($banner_image,'url');
		$show_breadcrumb = beautyzone_set($theme_options,'show_breadcrumb',true);
		$banner_hide   			= beautyzone_set($theme_options,$template_name.'_banner_hide');
	}


	$page_heading_classes = 'dlab-bnr-inr-entry';
	
	$banner_class = (empty($banner_image)) ?'bnr-no-img ':'';
	
	
	if($banner_height == 'page_banner_big') {
		$banner_class .= 'dlab-bnr-inr overlay-primary dlab-bnr-inr-lg';
		$page_heading_classes = 'dlab-bnr-inr-entry';
	}else if($banner_height == 'page_banner_medium'){
		$banner_class .= 'dlab-bnr-inr overlay-primary dlab-bnr-inr-md';
	}else if($banner_height == 'page_banner_small'){
		$banner_class .= 'dlab-bnr-inr overlay-primary dlab-bnr-inr-sm';
	}else if($banner_height == 'page_banner_custom'){
		//but you can't add height attribute here as per themeforest requirement
	}

	if($show_banner)
		{
			if($banner_type == 'image' )
			{
			?>
			<div class="<?php echo esc_attr($banner_class); ?>" 
			<?php if(!empty($banner_image) && empty($banner_hide)) { ?>style="background-image:url(<?php echo esc_url($banner_image); ?>)" <?php } ?>>
				<div class="container">
					<div class="<?php echo esc_attr($page_heading_classes); ?>">
						
						<?php if($header_style == 'header_3' && !empty($page_banner_sub_title)) { ?>
							<p> <?php echo wp_kses($page_banner_sub_title,'string'); ?></p>
						<?php } ?>
						
						<h1 class="text-white">
							<?php 
							$title = wp_title('',0); 
							if($title)
							{
								if(
									beautyzone_is_woocommerce_active() &&
									(
										(function_exists('is_shop') && is_shop()) || 
										(function_exists('is_product_category') && is_product_category())
									)
								  )
								{
									$title_prefix = ''; /* To remove extra product word from title */
                  
									$page_banner_title = beautyzone_set($theme_options,'woocommerce_page_title');
								}
								
								if(!empty($page_banner_title))
								{
									$title = $page_banner_title;
								}else{
									$title = $title_prefix.' '.$title;	
								}
								
								echo wp_kses($title,'string');
							}else{
								echo beautyzone_set($theme_options,'blog_page_title',esc_html__('Blog','beautyzone'));
							}
							?>
						</h1>
						 <!-- Breadcrumb row -->
						<?php if($show_breadcrumb) { ?>
							<div class="breadcrumb-row">
								<div class="container">
									<?php echo beautyzone_get_the_breadcrumb(); ?>
								</div>
							</div>
						<?php } ?>
						<?php if($banner_height == 'page_banner_big') { ?>
							<span class="line"></span>
						<?php } ?>
					</div>
				</div>
			</div>
			<?php	
			}		
		}
	
}

function beautyzone_get_post_banner()
{
    if (!is_single())
    {
        return false;
    }

    global $beautyzone_option;
	
	

    $header_style = isset($beautyzone_option['header_style'])?$beautyzone_option['header_style']:'header_1';
    $theme_options = beautyzone_get_theme_option();

    $post_key = 'post';
	
	if(is_singular('dz_service')){
		
		$post_key = 'service_post';
		$post_banner_setting = 'custom';
		
	}else{
		$post_banner_setting	= beautyzone_dzbase()->get_meta('post_banner_setting'); 
		$post_banner_setting	= !empty($post_banner_setting)?$post_banner_setting:'theme_default';
	}
	
	
	
    if ($post_banner_setting == 'custom')
    {
        $show_banner = beautyzone_dzbase()->get_meta($post_key.'_banner_on');
        $banner_image = beautyzone_dzbase()->get_meta($post_key.'_banner');
        $banner_height = beautyzone_dzbase()->get_meta($post_key.'_banner_height');
        $banner_image = beautyzone_set($banner_image, 'url');
        $show_breadcrumb = beautyzone_dzbase()->get_meta($post_key.'_breadcrumb');
	 
       
    }
    else
    {		
        $show_banner = beautyzone_set($theme_options, 'post_general_banner_on', true);
        $banner_height = beautyzone_set($theme_options, 'post_general_banner_height', 'page_banner_small');
        $banner_image = beautyzone_set($theme_options, 'post_general_banner');
        $banner_image = beautyzone_set($banner_image, 'url');
        $show_breadcrumb = beautyzone_set($theme_options, 'show_breadcrumb', true);
    }
   
	$page_heading_classes = 'dlab-bnr-inr-entry';
	$banner_class = (empty($banner_image)) ?'bnr-no-img ':'';
	if($banner_height == 'page_banner_big') {
		$banner_class .= 'dlab-bnr-inr overlay-primary dlab-bnr-inr-lg';
		$page_heading_classes = 'dlab-bnr-inr-entry';
	}else if($banner_height == 'page_banner_medium'){
		$banner_class .= 'dlab-bnr-inr overlay-primary dlab-bnr-inr-md';
	}else if($banner_height == 'page_banner_small'){
		$banner_class .= 'dlab-bnr-inr overlay-primary dlab-bnr-inr-sm';
	}else if($banner_height == 'page_banner_custom'){
		//but you can't add height attribute here as per themeforest requirement
	}
	
    if ($show_banner)
    {
	
		
			?>
			<div class="<?php echo esc_attr($banner_class); ?>" 
			<?php if(!empty($banner_image) && empty($banner_hide)) { ?>style="background-image:url(<?php echo esc_url($banner_image); ?>)" <?php } ?>>
				<div class="container">
					<div class="<?php echo esc_attr($page_heading_classes); ?>">
						
						<?php if($header_style == 'header_3' && !empty($page_banner_sub_title)) { ?>
							<p> <?php echo wp_kses($page_banner_sub_title,'string'); ?></p>
						<?php } ?>
						
						<h1 class="text-white">
						
							<?php 
							if(is_page() || is_single()){
								global $post;
								$title = isset($post->post_title)?$post->post_title:'';
							}else{
								$title = wp_title('',0); 
							}
							
							if($title)
							{
								echo wp_kses($title,'string');
							}else{
								echo beautyzone_set($theme_options,'blog_page_title',esc_html__('Blog','beautyzone'));
							}
							?>
						</h1>
             <!-- Breadcrumb row -->
              <?php if($show_breadcrumb) { ?>
              <div class="breadcrumb-row">
                <div class="container">
                  <?php echo beautyzone_get_the_breadcrumb(); ?>
                </div>
              </div>
              <?php } ?>
						<?php if($banner_height == 'page_banner_big') { ?>
							<span class="line"></span>
						<?php } ?>
					</div>
				</div>
			</div>
			<?php	
			

    }

}

function beautyzone_is_post_banner_enable()
{
    if (!is_single())
    {
        return false;
    }

    $post_banner_setting = beautyzone_dzbase()->get_meta('post_banner_setting');
    $post_banner_setting = !empty($post_banner_setting) ? $post_banner_setting : 'theme_default';

    if ($post_banner_setting == 'custom')
    {
        $show_banner = beautyzone_dzbase()->get_meta('post_banner_on');
    }
    else
    {
        $show_banner = beautyzone_get_opt('post_general_banner_on');
    }
    return $show_banner;
}

function beautyzone_get_loader()
{
	
	$theme_options 	= beautyzone_get_theme_option();

	$page_loading_on	= beautyzone_set($theme_options,'page_loading_on');

	if($page_loading_on == 1)
		{
			$page_loader_type	= beautyzone_set($theme_options,'page_loader_type','loading_image');
			if($page_loader_type == 'loading_image')
			{
				$custom_preloader = beautyzone_set($theme_options['custom_page_loader_image'],'url');
				if($custom_preloader) 
				{
					$preloader = $custom_preloader;
				
				}else{
					$page_loader_image = beautyzone_set($theme_options, 'page_loader_image', 'loading1');
					
					$preloader 	= get_template_directory_uri().'/dz-inc/assets/images/loading-images/'.$page_loader_image.'.svg';
					
					$loader1_default = '';
					if($page_loader_image == 'loading1'){
						$loader1_default = get_template_directory_uri().'/dz-inc/assets/images/loading-images/loading.png';
					}
					
					
				}
			}	
			elseif($page_loader_type == 'advanced_loader')
			{
				$page_loader = beautyzone_set($theme_options, 'advanced_page_loader_image', 'loading1');
			}	
		}
	?>


	<?php if($page_loading_on == 1) { ?>
	
	<?php 
	
	if($page_loader_type == 'loading_image') { 
			if(!empty($loader1_default)) {
		?>
			<div id="loading-area" style="background-image: url(<?php echo esc_url($preloader);?>), url(<?php echo esc_url($loader1_default);?>);"></div>
			
		<?php } else { ?>
		<!-- Preloader -->
		<div id="loading-area-default" style="background-image: url(<?php echo esc_url($preloader);?>);"></div>
	<?php } 
	}
	?>
	
	<?php 
	if($page_loader_type == 'advanced_loader' && $page_loader == 'loading1') { 
	?>
	<div id="loading-area" class="loader2">
		<div class="box-load">
			<div class="load-logo"><?php do_action( 'beautyzone_get_logo','site_other_logo'); ?></div>
			<h1 class="ml12"><?php echo esc_html__('Your Wait Is Going To Finish','beautyzone'); ?></h1>
		</div>	
	</div>
	<?php 
		wp_enqueue_script( 'beautyzone-anime', get_template_directory_uri().'/assets/js/loading/anime.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_script( 'beautyzone-anime-app3', get_template_directory_uri().'/assets/js/loading/anime-app3.js', array( 'jquery' ), '1.0', true );
	}elseif($page_loader_type == 'advanced_loader' && $page_loader == 'loading2') {
		wp_enqueue_style( 'beautyzone-loading2', get_template_directory_uri() . '/assets/css/loader/loading2.css' );
	?>
	<div id="loading-area" class="line-loader">
		<svg viewBox="0 0 960 300">
			<symbol id="s-text">
				<text text-anchor="middle" x="50%" y="80%"><?php echo get_bloginfo('name'); ?></text>
			</symbol>
			<g class = "g-ants">
				<use xlink:href="#s-text" class="text-copy"></use>
				<use xlink:href="#s-text" class="text-copy"></use>
				<use xlink:href="#s-text" class="text-copy"></use>
				<use xlink:href="#s-text" class="text-copy"></use>
				<use xlink:href="#s-text" class="text-copy"></use>
			</g>
		</svg>
	</div>
	<?php 
		}  
	} 
}


function beautyzone_isAMultipleOf4($n) 
{ 
    // if true, then 'n' is a multiple of 4 
    if (($n & 3) == 0) 
        return true; 
  
    // else 'n' is not a multiple of 4 
    return false; 
} 

/* Change Default WordPress Pages Sorting */
function beautyzone_change_default_pages_post_order( $query ) 
{
	$template_name = '';
	
	if($query->is_author() && $query->is_main_query() ){
		$template_name	= 'author_page';
	}else if($query->is_search() && $query->is_main_query() ){
		$template_name	= 'search_page';
	}else if( $query->is_category() && $query->is_main_query() ){
		$template_name	= 'category_page';
	}else if($query->is_tag() && $query->is_main_query() ){
		$template_name	= 'tag_page';
	}else if($query->is_archive() && $query->is_main_query() ){
		$template_name	= 'archive_page';
	}
	
	if(!empty($template_name))
	{
		$sorting_on = beautyzone_get_opt($template_name.'_sorting_on');
		if($sorting_on)
		{
			$sorting	= beautyzone_get_opt($template_name.'_sorting');
			
			if($sorting	== 'most_visited')
			{
				$order	=	'asc';
				$query->set('meta_key', '_views_count');	
				
			}else{
				$sort_arr	= explode('_',$sorting);
				$orderby 	= !empty($sort_arr[0]) ? $sort_arr[0]:'date';
				$order 		= !empty($sort_arr[1]) ? $sort_arr[1]:'DESC';
				
				$query->set('orderby', $orderby);	
			}
			
			$query->set('order', $order);	
		}
	}
}

add_action( 'pre_get_posts', 'beautyzone_change_default_pages_post_order' );
/* Change Default WordPress Pages Sorting END */

/* Change Body Layout */
function beautyzone_body_layout_class( $classes ) 
{
	$theme_layout = beautyzone_get_opt('theme_layout');
	
	if(!empty($theme_layout))
	{
		$class = '';
		if($theme_layout == 'theme_layout_2') 
		{
			/* Boxed Layout */
			$class = 'boxed';	
		}else if($theme_layout == 'theme_layout_3')
		{
			/* Frame Layout */
			$class = 'frame';
		}
		return array_merge( $classes, array( $class ) );
	}
	
	return $classes;
	
}
add_filter( 'body_class', 'beautyzone_body_layout_class');
/* Change Body Layout END */

/* Change Body Layout Style */
function beautyzone_body_layout_style() 
{
	$theme_options = beautyzone_get_theme_option();
	$theme_layout  = beautyzone_set($theme_options,'theme_layout','theme_layout_1');
	$style = '';
	if(!empty($theme_layout) && $theme_layout != 'theme_layout_1')
	{
		$output   = '';
		$bg_type  = beautyzone_set($theme_options,'body_boxed_bg_type');
		if($bg_type == 'bg_type_color')
		{
			$bg_color  = beautyzone_set($theme_options,'boxed_layout_bg_color');
			$custom_bg_color  = beautyzone_set($theme_options,'boxed_layout_custom_bg_color');
			
			if(!empty($custom_bg_color['color']))
			{
				$output = 'background-color:'.$custom_bg_color['color'].';';
			}else if(!empty($bg_color))
			{
				$output = 'background-color:'.$bg_color.';';
			}
		}else if($bg_type == 'bg_type_image')
		{
			$bg_image  = beautyzone_set($theme_options,'boxed_layout_bg_image');
			$custom_bg_image  = beautyzone_set($theme_options,'boxed_layout_custom_bg_image');
			
			if(!empty($custom_bg_image['url']))
			{
				$output = 'background-image:url('.$custom_bg_image['url'].'); background-size: auto;';
			}else if(!empty($bg_image))
			{
				$bg_image = get_template_directory_uri().'/assets/images/switcher/background/'.$bg_image.'.jpg';
				$output = 'background-image:url('.$bg_image.'); background-size: auto;';
			} 
			
		}else if($bg_type == 'bg_type_pattern')
		{
			$bg_pattern  = beautyzone_set($theme_options,'boxed_layout_bg_pattern');
			$custom_bg_pattern  = beautyzone_set($theme_options,'boxed_layout_custom_bg_pattern');
			
			$custom_bg_pattern_padding  = beautyzone_set($theme_options,'boxed_layout_bg_pattern_padding');
			
			if(!empty($custom_bg_pattern['url']))
			{
				$output = 'background-image:url('.$custom_bg_pattern['url'].'); background-size: auto;';
			}else if(!empty($bg_pattern))
			{
				$bg_pattern = get_template_directory_uri().'/assets/images/switcher/pattern/'.$bg_pattern.'.jpg';
				$output = 'background-image:url('.$bg_pattern.'); background-size: auto;';
			}
			
			if(!empty($custom_bg_pattern_padding))
			{
				$output .= 'padding:'.$custom_bg_pattern_padding.'px;';
			}				
		}
		$style = 'style="'.$output.'"';	
				
		
	}
	
	echo wp_kses_post($style);
}
/* Change Body Layout Style END */


function beautyzone_get_post_meta( $post_id, $meta_key ) 
{
	$value = get_post_meta($post_id,$meta_key);
	$value = !empty($value[0])?$value[0]:'';
	return $value;
}

function beautyzone_vc_build_link($btn_arr){
      $btn_data = array();
      if(function_exists('vc_build_link')){
        $btn_data = vc_build_link( $btn_arr );
      }
      
      return $btn_data;
    }

function beautyzone_get_category_by_post_id($post_id)
    {
       $cats = '';
       $cat_list = get_the_category($post_id);
        if(!empty($cat_list))
        {
          foreach($cat_list as $cat)
          {
              $cats .= '<a href="'.esc_url(get_category_link($cat->term_id)).'" class="post-link-in">'.esc_html($cat->name).'</a>';
          }
        }
        
        return $cats;
    
    }
	
if( !function_exists( 'beautyzone_generate_rand_number' ) )
{
	function beautyzone_generate_rand_number($digit=6)
	{
	  $no = substr(strtoupper(md5(uniqid(rand()))),0,$digit);
	  return $no;
	}
}

if(!function_exists( 'beautyzone_get_cat_id_by_slug' ) )
{
	/* Slugs may be array or comma seperated string */
	function beautyzone_get_cat_id_by_slug($slugs,$taxonomy='category')
	{
	$cat_id = array();
		if(!is_array($slugs)){
			$slugs = explode(',',$slugs);
		}

	if(!empty($slugs)){
		foreach($slugs as $slug){
			$category = get_term_by('slug',$slug,$taxonomy);
			if(!empty($category->term_id)){
				$cat_id[] = $category->term_id;
			}
		}
	}

	return $cat_id;
	}
}

/* Deafault Search Filter: remove pages from search */

add_filter('register_post_type_args', 'beautyzone_filter_search_result', 10, 2);

if(!function_exists( 'beautyzone_filter_search_result' ) )
{
	function beautyzone_filter_search_result($args, $post_type) 
	{
		if (!is_admin() && $post_type == 'page') 
		{
			$args['exclude_from_search'] = true;
		}
		return $args;
	}
}



/*
 * Return Current Page ID
 */
function beautyzone_get_current_page_id() {
	$current_page = -1;
	
	if ( is_front_page() && is_home() ) {
		$page_for_posts = get_option( 'page_for_posts' );
		if( ! empty( $page_for_posts ) && $page_for_posts != -1 ) {
			$current_page = $page_for_posts;
		}
	} elseif ( is_front_page() ) {
		$page_id = get_option('page_on_front');
		if( ! empty( $page_id ) && $page_id != -1 ) {
			$current_page = $page_id;
		}
	} elseif ( is_home() ) {
		// Blog page
		$page_for_posts = get_option( 'page_for_posts' );
		if( ! empty( $page_for_posts ) && $page_for_posts != -1 ) {
			$current_page = $page_for_posts;
		}
	} elseif ( ( function_exists('is_projects_archive') && is_projects_archive() ) || ( function_exists('is_project_category') && is_project_category() ) ) {
		$projects_page_id = projects_get_page_id( 'projects' );
		if( ! empty( $projects_page_id ) && $projects_page_id != -1 ) {
			$current_page = projects_get_page_id( 'projects' );
		}
	} elseif( is_post_type_archive( 'team-member' ) ) {
		$team_member  = -1;
	} elseif( function_exists('is_shop') && is_shop() ) {
		$current_page = get_option( 'woocommerce_shop_page_id' );
	} elseif( function_exists('is_product_category') && is_product_category() ) {
		$current_page = get_option( 'woocommerce_shop_page_id' );
	} elseif( function_exists('is_product_tag') && is_product_tag() ) {
		$current_page = get_option( 'woocommerce_shop_page_id' );
	} elseif( function_exists( 'is_project' ) && is_project() ) {
		$current_page = get_the_ID();
	} elseif( is_404() ) {
		$current_page = -2;
	} elseif( is_page() ) {
		$current_page = get_the_ID();
	} elseif ( is_post_type_archive('post') ) {
		$page_for_posts = get_option( 'page_for_posts' );
		if( ! empty( $page_for_posts ) && $page_for_posts != -1 ) {
			$current_page = $page_for_posts;
		}
	}
	
	return $current_page;
}