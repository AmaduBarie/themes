<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive.
 *
 * Override this template by copying it to yourtheme/woocommerce/archive-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.6.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$show_sidebar	= beautyzone_dzbase()->get_meta('page_show_sidebar', get_option( 'woocommerce_shop_page_id' ));
$layout			= beautyzone_dzbase()->get_meta('page_sidebar_layout', get_option( 'woocommerce_shop_page_id' ));
$sidebar		= beautyzone_dzbase()->get_meta('page_sidebar', get_option( 'woocommerce_shop_page_id' ));

$title = beautyzone_get_opt('woocommerce_page_title');

$layout = (!$show_sidebar)?'full':$layout;

if(isset($_GET['layout'])){
	$layout = $_GET['layout'];
}

if($layout == 'full' || !is_active_sidebar( $sidebar ) )
{
	$classes = 'col-lg-12 col-md-12 col-sm-12 col-12';
}else{
	$classes = 'col-lg-9 col-md-7 col-sm-6';
}
$title = beautyzone_get_opt('woocommerce_page_section_heading');
get_header( 'shop' );
 ?>
 <!--Start breadcrumb area-->     
<?php beautyzone_get_banner(); ?>
<!--End breadcrumb area-->

<!-- contact area -->
<div class="content-inner section-full bg-white">
  <!-- Product -->
  <div class="container">
    <div class="row">
    <!-- sidebar area -->
      <?php if( $layout == 'left' ){ ?>
          <?php if ( is_active_sidebar( $sidebar ) ) { ?>
             <div class="col-lg-3 col-md-5 col-sm-6">
                <?php dynamic_sidebar( $sidebar ); ?>
                <?php do_action( 'woocommerce_sidebar' );?>
            </div>
          <?php } ?>
      <?php } ?>
      <!-- sidebar area -->
      <div class="<?php echo esc_attr($classes);?>">
        <div class="text-center m-b30">
          <h2 class="m-t0 text-primary"><?php echo esc_html($title); ?></h2>
          <div class="dez-separator-outer "><div class="dez-separator bg-primary style-skew"></div> </div>
        </div>
        <div class="row" id="masonry">
            <!--<div class="col-12">
              <div class="row sort-space">
                  <?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
                  <div class="col-lg-4 col-md-5 col-sm-6 col-7">
                      <?php do_action( 'woocommerce_before_shop_loop' );?>
                  </div>
                  <?php endif;?>
                  <div class="col-lg-8 col-md-7 col-sm-6 col-5">
                      <div class="shop-tab float-right">
                          <ul class="nav text-center product-filter" role="tablist">
                              <li class="nav-item">
                                  <a class="nav-link active" data-toggle="tab" href="#Grid"><i class="fa fa-list-ul" aria-hidden="true"></i></a>
                              </li>
                              <li class="nav-item">
                                  <a class="nav-link " data-toggle="tab" href="#List"><i class="fa fa-th-large" aria-hidden="true"></i></a>
                              </li>
                          </ul>
                      </div>
                  </div>
              </div>
            </div>-->
          <div class="col-12 tab-content">
            <?php do_action( 'woocommerce_before_main_content' );?>
            <?php do_action( 'woocommerce_archive_description' );?>
            <div class="tab-pane active" id="Grid" role="tabpanel">
              <?php if ( have_posts() ) { ?>
          <div class="row">
            <?php woocommerce_product_loop_start(); ?>
      
              <?php woocommerce_product_subcategories(); ?>
      
              <?php while ( have_posts() ) { the_post(); ?>
      
                <?php wc_get_template_part( 'content', 'product' ); ?>
      
              <?php } // end of the loop. ?>
      
            <?php woocommerce_product_loop_end(); ?>
          </div>
          
            <?php
              /**
               * woocommerce_after_shop_loop hook
               *
               * @hooked woocommerce_pagination - 10
               */
              do_action( 'woocommerce_after_shop_loop' );
          
          } else if ( ! woocommerce_product_subcategories( array( 'before' => woocommerce_product_loop_start( false ), 'after' => woocommerce_product_loop_end( false ) ) ) ) { ?>
          <div class="row">
            <?php wc_get_template( 'loop/no-products-found.php' ); ?>
          </div>
          <?php } ?>
          </div>  
          <div class="tab-pane fade" id="List" role="tabpanel">
            <?php if ( have_posts() ) { ?>
            <div class="row m-0">
              <?php woocommerce_product_loop_start(); ?>
          
                <?php woocommerce_product_subcategories(); ?>
        
                <?php while ( have_posts() ) { the_post(); ?>
        
                  <?php wc_get_template_part( 'list', 'product' ); ?>
        
                <?php } // end of the loop. ?>
        
              <?php woocommerce_product_loop_end(); ?>
            </div>
            <?php
              /**
               * woocommerce_after_shop_loop hook
               *
               * @hooked woocommerce_pagination - 10
               */
              do_action( 'woocommerce_after_shop_loop' );
            ?>
             <?php } else if ( ! woocommerce_product_subcategories( array( 'before' => woocommerce_product_loop_start( false ), 'after' => woocommerce_product_loop_end( false ) ) ) ) { ?>
              <div class="row m-0">
                <?php wc_get_template( 'loop/no-products-found.php' ); ?>
              </div>
            <?php } ?>
          </div>
          <?php do_action( 'woocommerce_after_main_content' );?>
          </div>
        </div>
      </div>
      <!-- sidebar area -->
      <?php if( $layout == 'right' ){ ?>
          <?php if ( is_active_sidebar( $sidebar ) ) { ?>
             <div class="col-lg-3 col-md-5 col-sm-6">
                <?php dynamic_sidebar( $sidebar ); ?>
                <?php do_action( 'woocommerce_sidebar' );?>
            </div>
          <?php } ?>
      <?php } ?>
    </div>
  </div>
  <!-- Product END -->
</div>
        <!-- contact area  END -->
<?php get_footer( 'shop' ); ?>

